#OK

def giveAnsOfP4(no):
    
    if no=='701' or no=='702':
        print('Train name: Subarna Express')
    elif no=='703':
        print('Train name: Mohanagar Goduli')
    elif no=='704':
        print('Train name: Mohanagar Provati')    
    elif no=='705' or no=='706':
        print('Train name: Ekota Express')     
    elif no=='707' or no=='708':
        print('Train name: Tista Express')
    elif no=='709' or no=='710':
        print('Train name: Parabat Express')     
    elif no=='711' or no=='712':
        print('Train name: Upukol Express')
    elif no=='713' or no=='714':
        print('Train name: Karutoa Express')         
    elif no=='717' or no=='718':
        print('Train name: Joyantika Express')     
    elif no=='719' or no=='720':
        print('Train name: Paharika Express')
    elif no=='721' or no=='722':
        print('Train name: Mohanagar Express')     
    elif no=='723' or no=='724':
        print('Train name: Uddayan Express')
    elif no=='729' or no=='730':
        print('Train name: Meghna Express')
    elif no=='735' or no=='736':
        print('Train name: Agnibina Express')
    elif no=='737' or no=='738':
        print('Train name: Egarosindhur Provati')     
    elif no=='739' or no=='740':
        print('Train name: Upaban Express')
    elif no=='741' or no=='742':
        print('Train name: Turna Express')         
    elif no=='743' or no=='744':
        print('Train name: Bharamaputra Express')     
    elif no=='749' or no=='750':
        print('Train name: Egarosindhur Goduli')
    elif no=='751' or no=='752':
        print('Train name: lalmoni Express')     
    elif no=='757' or no=='758':
        print('Train name: Drutojan Express')
    elif no=='767' or no=='768':
        print('Train name: Dolonchapa Express') 
    elif no=='771' or no=='772':
        print('Train name: Rangpur Express')
    elif no=='773' or no=='774':
        print('Train name: Kalani Express')         
    elif no=='777' or no=='778':
        print('Train name: Hoar Express')     
    elif no=='781' or no=='782':
        print('Train name: Kishorgonj Express')
    elif no=='785' or no=='786':
        print('Train name: Bijoy Express')     
    elif no=='787' or no=='788':
        print('Train name: Sonar Bangla')
    elif no=='789' or no=='790':
        print('Train name: Mohangonj Express')
    elif no=='715' or no=='716':
        print('Train name: Kapotaskh Express') 
    elif no=='725' or no=='726':
        print('Train name: Sundarban Express')
    elif no=='727' or no=='728':
        print('Train name: Rupsha Express')         
    elif no=='731' or no=='732':
        print('Train name: Barendra Express')     
    elif no=='733' or no=='734':
        print('Train name: Titumir Express')
    elif no=='747' or no=='748':
        print('Train name: Simanta Express')     
    elif no=='745' or no=='746':
        print('Train name: Jamuna Express') 
    elif no=='753' or no=='754':
        print('Train name: Silk City')
    elif no=='755' or no=='756':
        print('Train name: Madhumati Express')       
    elif no=='759' or no=='760':
        print('Train name: Padma Express') 
    elif no=='761' or no=='762':
        print('Train name: Sagardari Express')
    elif no=='763' or no=='764':
        print('Train name: Chittra Express')         
    elif no=='765' or no=='766':
        print('Train name: Nilsagar Express')     
    elif no=='769' or no=='770':
        print('Train name: Dhumketue Express')
    elif no=='775' or no=='776':
        print('Train name: Sirajgonj Express')     
    elif no=='779' or no=='780':
        print('Train name: Kalukhali Vatiap')
    elif no=='783' or no=='784':
        print('Train name: Faridpur Express')
    elif no=='793' or no=='794':
        print('Train name: Panchagarh Express')
    elif no=='797' or no=='798':
        print('Train name: Kurigram Express')
    elif no=='3107' or no=='3110' or '3108' or no=='3109':
        print('Train name: Moitree Express')     
    elif no=='3129' or no=='3130':
        print('Train name: Bandhan Express')

     
    else:
        print('Invalid Train number')  