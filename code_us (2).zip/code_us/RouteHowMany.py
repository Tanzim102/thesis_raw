#OK

final_destination=['dhaka', 'chittagong', 'santaher', 'rajshahi', 'khulna', 'kolkata', 'faridpur', 'rajbari', 'dinajpur',
                   'dewanganj_bazar', 'chandpur', 'tarakandi', 'sylhet', 'noakhali', 'burimari', 'kishoreganj', 'rangpur',
                   'mohonganj', 'lalmonirhat', 'mymensingh', 'chilahati', 'goalandaghat', 'sirajganj', 'vatiapara_ghat']
                   
def RouteHowMany(s,a,b):
    if a in final_destination and b in final_destination:
        if ("dhaka" in s):
            if ("dinajpur" in s):
                print('3')
            elif ("khulna" in s):
                print('2')
            elif ("chittagong" in s):
                print('5')
            elif ("dewanganj_bazar" in s):
                print('2')
            elif ("tarakandi" in s):
                print('2')
            elif ("rajshahi" in s):
                print('4')
            elif ("sylhet" in s):
                print('4')
            elif ("noakhali" in s):
                print('1')
            elif ("kishoreganj" in s):
                print('3')
            elif ("rangpur" in s):
                print('2')
            elif ("mohonganj" in s):
                print('2')
            elif ("lalmonirhat" in s):
                print('1')
            elif ("sirajganj" in s):
                print('1')
            elif ("chilahati" in s):
                print('1')
            else:
                print('does not go there or search with final destination')
                
                
                
        elif ("khulna" in s):
            if ("rajshahi" in s):
                print('2')
            elif ("chilahati" in s):
                print('2')
            elif ("kolkata" in s):
                print('1')
            else:
                print('does not go there or search with final destination')
                
                
                
        elif ("chittagong" in s):
            if ("sylhet" in s):
                print('2')
            elif ("chandpur" in s):
                print('1')
            elif ("mymensingh" in s):
                print('1')
            else:
                print('does not go there or search with final destination')
            
            
            
        elif ("rajshahi" in s):
            if ("chilahati" in s):
                print('2')
            elif ("goalandaghat" in s):
                print('1')
            else:
                print('does not go there or search with final destination')
                
                
                
        elif ("santaher" in s):
            if ("burimari" in s):
                print('1')
            elif ("dinajpur" in s):
                print('1')
            else:
                print('does not go there or search with final destination')
                
                
                
        elif ("rajbari" in s):
            if ("faridpur" in s):
                print('1')
            else:
                print('does not go there or search with final destination')
                
                
                
        elif ("vatiapara_ghat" in s):
            if ("goalandaghat" in s):
                print('1')
            elif ("rajbari" in s):
                print('1')
            else:
                print('does not go there or search with final destination')
            
            
            
    else:
        print('please search with the final station')





    
            
            
            
        
            
    
    #elif ("chittagong" in s):
        
    #elif ("rajshahi" in s):
        
    #elif ("khulna" in s):
        
    #elif ("santaher" in s):
    
    #elif ("vatiapara Ghat" in s):
        
    #elif ("rajbari" in s):
        
