# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 21:20:12 2019

@author: CITY
"""

import nltk

#nltk.download('stopwords')
#nltk.download('punkt')
#nltk.download('wordnet')
nltk.download('averaged_perceptron_tagger')