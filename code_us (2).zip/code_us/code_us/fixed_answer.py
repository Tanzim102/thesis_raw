#OK

def fixed_answer(s):
    if "largest station" in s:
        print('Kamalapur Railway Station')
    elif "Bangladesh Railway cover" in s:
        print('In 2015, Bangladesh Railway serviced 489 railway stations.')
    elif "rail minister" in s:
        print('Mujibul Haque Mujib')
    elif "costly" in s:
        print('no')
    elif "food" in s:
        print('yes')
    elif "When the Bangladesh Railways introduced in Bangladesh" in s:
        print('1862')
    elif "Which services does BR provide" in s:
        print('national including Kolkata')
    elif "need printed copy of online ticket" in s:
        print('yes')
    
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    else:
        print('...Pattern DOES not MATCH...')