# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 21:18:10 2019

@author: CITY
"""

from nltk.tokenize import sent_tokenize, word_tokenize
from collections import Counter 
# Import WordNetLemmatizer
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import nltk
import re
from decimal import Decimal

from fixed_answer import *
from WhereGoesOrComes import * #1
from RouteHowMany import * #2
from RouteTrainNameNo import * #2
from OnlyNumber import * #3
from OnlyName import * #4
from Offday import * #5&6
from listOfTrainsforAnyPlace import * #7
from train_time import * #8
from seatFair import * #9
from ACavailable import * #10
from trainAvailable import * #11
from nextStation import * #12
from how_long_it_takes import * #13


ENGLISH_STOPS = set(stopwords.words('english'))

lenPattern=[8,7]
whQues=["who","what","where","how","why","when","which"]
pre=["to","from"] 
yes_no=["is","can","are","does","there"]
extra=["approximate","approriate","there","express"]
cut=["why","buy","book","bought","coordinate","ticket"]

tokennns=[]
nouns=[]
place_add=[]

string=""
pattern_match=[]
vowels=["a","e","i","o","u","h"]

train_name=['701','702','703','704','705','706','707','708','709','710','711','712','713','714','715','716',
            '717','718','719','720','721','722','723','724','725','726','727','728','729','730','731','732','733','734','735',
            '736','737','738','739','740','741','742','743','744','745''746','747','748','749','750','751','752','753','754','755',
            '756','757','758','759','760','761','762','763','764','765','766','767','768','769','770','771','772','773',
            '774','775','776','777','778','779','780','781', '782','783','784','785','786','787', '788','789','790','793','794'
            '3107','3108','3109','3110','3129','3130',
            'augnibina',   
            'banalata','bandhan','bijoy','borendra','brahmaputro',
            'chitra', 
            'dhumkatu','doloncapa','drutajan',    
            'egarosindur_godhuli','egarosindur_provati','ekota', 
            'faridpur',
            'haowr',
            'jamuna','joyenteeka',    
            'kalni','kalukhali_vatiap','kishoreganj','korotaya','kopotakha','kurigram', 
            'lalmoni',
            'mahanagar','mahanagar_godhuli','mahanagar_provati','meghna','modhumati','moitree','mohonganj', 
            'padma','paharika','parabat','panchagarh',
            'nelsagore',
            'rangpur','rupsa',
            'seemanta','shagordari','silk_city','sirajganj','sonar_bangla','subarna','sundarban',
            'tista','titumir','turna',
            'udayan','upaban','upakul']

new_train_name=[ 'gnbn',   
            'bnlt','bndn','bjy','brndr','brmptr',
            'ctr', 
            'dmkt','dlncp','drtjn',    
            'grsndr_gdl','grsndr_prvt','kt', 
            'frdpr',
            'wr',
            'jmn','jyntk',    
            'kln','klkl_vtp','ksrgnj','krty','kptk','krgrm', 
            'llmn',
            'mngr','mngr_gdl','mngr_prvt','mgn','mdmt','mtr','mngnj', 
            'pdm','pik','prbt','pncgr',
            'nlsgr',
            'rngpr','rps',
            'smnt','sgrdr','slk_cty','srjgnj','snr_bngl','sbrn','sndrbn',
            'tst','ttmr',
            'dyn','pbn','pkl']

place_names=['abdulpur','accalpur','aditmari','agimnagar','ahasangang','akhaura','alamdanga','amirgang','aowlia_nagar',
             'arani','arikhola','ashuganj','azampur',
             
             'b_siajur_islam','badar_ganj','bajitpur','bamondanga','banani','bangabandhu_htp','barhatta','bajipur',
             'bbsetu_e','bbsetu_w','benapole','bhairab_bazar','bhanugach','bhairamara','bhanuganj','bhatiary',
             'biman_bandar','birampur','birole','bogura','bojra','bonar_para','boral_bridge','brahmanbaria','burimari'
             
             'chandpur','chapainababganj','chapta','chatmohar','chilahati','chittagong','choumuhani','chuadanga',
             'chitosi_road','cirir_bandar','comilla','court_chandpur','chandpur_court',
             
             'darsana','darsana_halt','daulatpur','da_cantonment','dewanganj_bazar','dhaka','dhaka_cantt',
             'dhoala','dinajpur','domar','durmut',
             
             'fatema_namar','feni','faridpur',
             
             'gachihata','gafargaon','gaibandha','goalondho','goalandaghat','gobra','gouripur_myn','gunaboti',
             
             'hajiganj','hasanpur','horoshpur','hatibandha',
             
             'ibrahimabad','imam_bari','ishurdi','ishurdi_dhaka','ishurdi_bypass','islampur_bazar',
             
             'jamalpur','jamalpur_town','jamtail','jaydebpur','jessore','jhikargacha','joypurhat',
             
             'kalukhali','kaunia','kawrait','khanabari','kholahati','khulna','kishoreganj','kismat',
             'krishi_univarsity','kulaura','kuliarchar','kurigram','kustia','kustia_court','kumarkhali','khoksa',
             
             'lahirimohanpur','laksam','lalmonirhat',
             
             'madhnagar','maijdi_court','maizgaon','manik_khali','melandah_bazar','methikanda','meher','mirpur',
             'mirzapur','mobarakgong','mohera','modhu_road','mohonganj','montala','mohimaganj','moshakhali','mouchak',
             'mukundupur','muladuli','mymensingh'
             
             'nandina','nangalkot','narsingdi','nathar_patua','natore','nayapara','neelfamari','netrokona','noakhali',
             'noapara','nurundi',
        
             'paghachong','panchabibi','panchagarh','parbatipur','patgram','phulbari','pirgacha','pirganj',
             'poradaha','pyerpur','pakshi','pangsha',
             
             'qosba',
             
             'rajapur','rajendrapur','rajshahi','rangpur','ruhiya','rajbari',
             
             'sadanandapur','saidpur','santaher','sararchar','sarisha_bari','satabgonj', 'satkhamaer',
             'sm_m_monsur_ali','shahagi_bazar','shaistagonj','shamshernagar','shemganj','shordha_road','shoshidol',
             'sirajganj','sirajganj_bazar','sonaimuri','sonatola', 'srimangal','sripur','syadabad','sylhet',
             
             'talora','tangail','tangi','tarakandi','tejgon','thakurakona','thakurgaon','thakurgaon_road','tushvandar',
             
             'ullapara',
             
             'vatiapara_ghat']





class_names=['tapanukul','first','1st','ac','second','2nd','shulov','shovan','non','s_chair','ac_b','ac_s','f_chair',
             'f_seat','snigdha']
            
          
            
def WhereGoesOrComes(): #1...........
    place=0
    flag=0
    flag2=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    aa=len(nouns)
    #  print(aa)
    
        
    for tt in nouns:
        for t in place_names:
            if t==tt:
                place=1
                place_add.append(t)
                
   
    for tt in nouns:
        for t in train_name:
            if t==tt:
                flag=1
                if place==1:
                    wheregoescomesfromto(t,place_add[0])
                else:
                    wheregoescomesfromto(t,'0')
        
    
                
    if flag==0:  
        for t in range(aa):
            for tt in nouns[t]:
                if tt in vowels:
                    nouns[t]=nouns[t].replace(tt,"")
                    
        for tt in new_train_name:
            for t in nouns:
                if tt==t:
                    flag2=1
                    if place==1:
                       wheregoescomesfromto(t,place_add[0]) 
                    else:
                        wheregoescomesfromto(t,'0')
                        
                    
    if flag==0 and flag2==0:
        print('please mention train name correctly')     
                
            
        

def RouteHowManyOrRouteTrainNameNo(): #2...........
    if("how many" in string):
        plus=0
        for word,pos in nltk.pos_tag(tokennns):
            nouns.append(word)
        
        for tt in nouns:
            for t in place_names:
                if t==tt:
                    plus=plus+1
                    place_add.append(t)
        if plus==2:
            a=place_add[0]
            b=place_add[1]
            RouteHowMany(string,a,b)
        elif plus==1:
            print('please mention full route')
        else:
            print('mention place name correctly')
            
            
    elif("what" in string or "give" in string or "tell" in string):
        plus=0
        for word,pos in nltk.pos_tag(tokennns):
            nouns.append(word)
        
        for tt in nouns:
            for t in place_names:
                if t==tt:
                    plus=plus+1
                    place_add.append(t)
        if plus==2:
            a=place_add[0]
            b=place_add[1]
            RouteTrainNameNo(a,b)
        elif plus==1:
            print('please mention full route')
        else:
            print('mention place name correctly')
            
            
    else:
        print('sorry, invalid')
        
        
        
        
        
        
def OnlyNumber(): #3...........
    flags=0
    flag2=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
  
    aa=len(nouns)
    for t in train_name:
        for tt in nouns:
            if t==tt and flags==0:
                giveAnsOfP3(t)
                flags=1
                break
    
    
    if flags==0:  
        for t in range(aa):
            for tt in nouns[t]:
                if tt in vowels:
                    nouns[t]=nouns[t].replace(tt,"")
                    
        for tt in new_train_name:
            for t in nouns:
                if tt==t:
                    giveAnsOfP3(t)
                    flags=1
                    break
                        
                    
    if flags==0 and flag2==0:
        print('please mention train name correctly')                                    
           

def OnlyName():  #4...........
    flag=0
    for word,pos in nltk.pos_tag(tokennns):
        if pos == 'CD':
            cd=word
            flag=1
            break
    
    if flag==1:
        giveAnsOfP4(cd)     



            
            
            
def Offday():   #5&6...........
    flags=0
    plus=0
    flag2=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    aa=len(nouns)          
        
    for t in train_name:
        for tt in nouns:
            if t==tt:
                offday_with_trainName(t)
                flags=1
                break
                
    if flags==0:
        for t in range(aa):
            for tt in nouns[t]:
                if tt in vowels:
                    nouns[t]=nouns[t].replace(tt,"")
                    
        for tt in new_train_name:
            for t in nouns:
                if tt==t:
                    flag2=1
                    offday_with_trainName(t)
           
            
    if flags==0 and flag2==0:
        for tt in nouns:
            for t in place_names:
                if t==tt and flags==0:
                    plus=plus+1
                    place_add.append(t)
        
        if plus==2:
            a=place_add[0]
            b=place_add[1]
            offday_with_route(a,b)
        elif plus==1:
            print('please mention full route')
        else:
            print('mention place name correctly')

        


                
def listOfPlace():   #7...........
    flag=0
    plus=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
        

    for tt in nouns:
        for t in place_names:
            if t==tt:
                plus=plus+1
                flag=1
                place_add.append(t)
                
    if flag==1:
        if plus==1:
            a=place_add[0]
            listOfTrainsforAnyPlace(a)
        else:
            print('mention one stoppage only')
        
            
    else:
        print('mention place name')




def seatFair_func():  #8...........
    plus=0
    one=0
    two=0
    three=0
    four=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    aa=len(nouns)
        
    for t in nouns:
        for tt in place_names:
            if t==tt:
                place_add.append(t)
                plus=plus+1
                one=1
                           
                
    if one==1:
        if plus==2:
            for t in class_names:
                for tt in nouns:
                    if t==tt:
                        two=1
                        place_add.append(t)
                        
            
            if two==1:
                for t in train_name:
                    for tt in nouns:
                        if t==tt:
                            three=1
                            place_add.append(t)
                            
                 
                if three==1:
                    
                    a=place_add[0]
                    b=place_add[1]
                    c=place_add[2]
                    t=place_add[3]
                    seatFair(a,b,c,t)
                    
                else:
                    for t in range(aa):
                        for tt in nouns[t]:
                            if tt in vowels:
                                nouns[t]=nouns[t].replace(tt,"")
                    
                    for tt in new_train_name:
                        for t in nouns:
                            if tt==t:
                                if tt=='kln':
                                    if place_add[0]!='khulna' and place_add[1]!='khulna':
                                        four=1
                                        place_add.append(t)
                                    
                                else:
                                    four=1
                                    place_add.append(t)
                                
                            
                    if four==1:
                        a=place_add[0]
                        b=place_add[1]
                        c=place_add[2]
                        t=place_add[3]
                        seatFair(a,b,c,t)
                        
                    else:
                        print('mention train name correctly')
                        
                            
            else:
                print('mention class name please')
                
           

                
        else:
            print('mention full route please')
          
    else:
        print('mention place name')
        


def nextOne():  #9...........
    flag=0
    flags=0
    flags2=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    aa=len(nouns)
    
    for tt in nouns:
        for t in place_names:
            if t==tt:
                flag=1
                place_add.append(t)
                break
                
                
    if flag==1:
        
        for tt in nouns:
            for t in train_name:
                if t==tt:
                    flags=1
                    place_add.append(t)
                    break

        if flags==0:
            for t in range(aa):
                for tt in nouns[t]:
                    if tt in vowels:
                        nouns[t]=nouns[t].replace(tt,"")
                    
            for tt in new_train_name:
                for t in nouns:
                    if tt==t:
                        flags2=1
                        place_add.append(t)
                        break
                    
                
        if flags==0 and flags2==0:
            print('please mention train name correctly')
        
        elif flags==1 or flags2==1:
           a=place_add[0]
           t=place_add[1]
           nextStation(t,a,string)
        else:
            print('mention one stoppage')
          
    else:
        print('mention place name')
            

            

def ACtrain_available():    #10...........
    flag=0
    plus=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    for t in nouns:
        for tt in place_names:
            if t==tt:
                flag=1
                plus=plus+1
                place_add.append(t)
            
    if flag==1:
        if plus==2:
            x=place_add[0]
            y=place_add[1]
            ACavailable(x,y)
        else:
            print('please provide full route information')
            
            
    else:
        print('not specified')      
        
        
        

def trainIfAvailable():   #11...........
    flag=0
    plus=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    for t in nouns:
        for tt in place_names:
            if t==tt:
                flag=1
                plus=plus+1
                place_add.append(t)
            
    if flag==1:
        if plus==2:
            x=place_add[0]
            y=place_add[1]
     
            trainAvailable(x,y)
        else:
            print('please provide full route information')
            
            
    else:
        print('not specified')
        
     
        
def timeFunc():  #12...........
    flag=0
    plus=0
    one=0
    temp=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    for t in nouns:
        for tt in place_names:
            if t==tt:
                flag=1
                plus=plus+1
                place_add.append(t)
                
                
    for t in train_name:
        for tt in nouns:
            if t==tt:
                one=t
                flag=1
                temp=1
                plus=plus+1
                
            
    if flag==1:
        if plus==1:
            print('please provide full route information')
        elif plus==2:
            if temp==1:
                print('please provide full route information')
            else:
                print('please provide train name')
        elif plus==3:
            x=place_add[0]
            y=place_add[1]
            train_time(x,y,one)
        else:
            print('please provide full information')
            
            
    else:
        print('not specified')
   
        
        
    
               
def howLong():  #13...........
    flag=0
    plus=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    for t in nouns:
        for tt in place_names:
            if t==tt:
                place_add.append(t)
                flag=1
                plus=plus+1
                
    
    if flag==1:
        if plus==2:
            a=place_add[0]
            b=place_add[1]
            how_long_it_takes(a,b)
        else:
            print('please provide full route information')
    else:    
        print('not specified')     
        
   
                            
    
def answer(patternNo,tokenn):
    string1=""
    for t in tokenn:
        if t not in ENGLISH_STOPS:
            tokennns.append(t);
            
    if patternNo==1:
        for t in pattern_match:
            if t=='from' or t=='to' or t=='train' or t=='name' or t=='number':
                string1=string1+"("+t+" " ")"+"?"
                
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)

        amounts=0
        p1=["from", "where", "train", "named", "numbered", "[a-z]*|\d{3,4}", "come", "travel", "start", "depart", "leave", "go", "to", "[a-z]*"]
        xx=len(p1)
        for t in pattern_match:
            for tt in p1:
                if t==tt:
                    amounts=amounts+1
        
        so=((amounts/(xx-5))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("is " + str(d) + "% matced as subset" )
        
        WhereGoesOrComes()
        
        
    elif patternNo==2:
        for t in pattern_match:
            if t=='from' or t=='to' or t=='train' or t=='name' or t=='number' or t=='per' or t=='day' or t=='many' or t=='juction' or t=='route' or t=='available' :
                string1=string1+"("+t+" " ")"+"?"
                
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)

        amounts=0
        p2=["per", "day", "what", "give", "tell", "how", "many", "junction", "route", "name", "number", "train", "available", "[a-z]*", "travel", "to", "from"]
        xx=len(p2)
        for t in pattern_match:
            for tt in p2:
                if t==tt:
                    amounts=amounts+1
  
        so=((amounts/(xx-3))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )
        
        RouteHowManyOrRouteTrainNameNo()
            
        
    elif patternNo==3:
        for t in pattern_match:
            if t=='[a-z]*|\d{3,4}':
                string1=string1+"("+'[a-z]*|\D{3,4}'+" " ")"
            elif t=='train' or t=='named':
                string1=string1+"("+t+" " ")"+"?"
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)
         
        amounts=0
        p3=["what", "give", "tell", "named", "number", "train", "[a-z]*|\d{3,4}"]
        xx=len(p3)
        for t in pattern_match:
            for tt in p3:
                if t==tt:
                    amounts=amounts+1
       
        so=((amounts/(xx-1))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )
        
        OnlyNumber()
        
    
    elif patternNo==4:
        for t in pattern_match:
            if t=='[a-z]*|\d{3,4}':
                string1=string1+"("+'\d{1,5}'+" " ")"
            elif t=='train' or t=='numbered':
                string1=string1+"("+t+" " ")"+"?"
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)
         
        amounts=0
        p4=["what", "give", "tell", "name", "numbered", "train", "[a-z]*|\d{3,4}"]
        xx=len(p4)
        for t in pattern_match:
            for tt in p4:
                if t==tt:
                    amounts=amounts+1
       
        so=((amounts/(xx-1))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )        
        
        OnlyName()
        
        
    
    elif patternNo==5:
    
        for t in pattern_match:
            if t=='train' or t=='numbered' or t=='named' or t=='day' or t=='from' or t=='to':
                string1=string1+"("+t+" " ")"+"?"
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)
         
        amounts=0
        p5=["which", "give", "tell", "day", "named", "numbered", "train", "[a-z]*|\d{3,4}", "[a-z]*", "go", "from", "to"]
        xx=len(p5)
        for t in pattern_match:
            for tt in p5:
                if t==tt:
                    amounts=amounts+1
       
        so=((amounts/(xx-2))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )        
        
        Offday()
        
        
        
    elif patternNo==6:
    
        for t in pattern_match:
            if t=='train' or t=='numbered' or t=='named' or t=='from' or t=='to':
                string1=string1+"("+t+" " ")"+"?"
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)
         
        amounts=0
        p6=["which", "what", "offday", "named", "numbered", "train", "[a-z]*|\d{3,4}", "[a-z]*", "from", "to"]
        xx=len(p6)
        for t in pattern_match:
            for tt in p6:
                if t==tt:
                    amounts=amounts+1
       
        so=((amounts/(xx-1))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )        
        
        Offday()
        
        
        
    elif patternNo==7:
       
        for t in pattern_match:
            if t=='number' or t=='name' or t=='list':
                string1=string1+"("+t+" " ")"+"?"
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)
         
        amounts=0
        p7=["give", "what", "tell", "name", "number", "train", "[a-z]*", "list"]
        xx=len(p7)
        for t in pattern_match:
            for tt in p7:
                if t==tt:
                    amounts=amounts+1
       
        so=((amounts/(xx-3))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )     
        
        listOfPlace()
        
        
        
    elif patternNo==8:
      
        for t in pattern_match:
            if t=='much' or t=='seat' or t=='traveling' or t=='going' or t=='train' or t=='from' or t=='to':
                string1=string1+"("+t+" " ")"+"?"
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)
         
        amounts=0
        p8=["give", "what", "tell", "how", "much", "seat", "fare", "[a-z]*", "amount", "cost", "price", "pay", "fee", "charge", "traveling", "going"]
        xx=len(p8)
        for t in pattern_match:
            for tt in p8:
                if t==tt:
                    amounts=amounts+1
       
        so=((amounts/(xx-9))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )  
        seatFair_func()
        
        
            
    elif patternNo==9:
        
        for t in pattern_match:
            if t=='station':
                string1=string1+"("+t+" " ")"+"?"
            else:
                string1=string1+"("+t+" " ")"
        print('the User pattern:')
        print(string1)
         
        amounts=0
        p9=["give", "what", "tell", "which", "next", "previous", "station", "[a-z]*"]
        xx=len(p9)
        for t in pattern_match:
            for tt in p9:
                if t==tt:
                    amounts=amounts+1
       
        so=((amounts/(xx-4))*100)
        d=Decimal(so).quantize(Decimal('1.00'))
        d=round(Decimal(so),2)
        print("with " + str(d) + "% matced" )     
        
        nextOne()
        
        
        
   
        
    elif patternNo==10:
        ACtrain_available()
        
        
    elif patternNo==11:
        trainIfAvailable()
        
        
    elif patternNo==12:
        timeFunc()
        
            
    elif patternNo==13:
        howLong()
        
        
        
        

    
   
    
def precision_count(strr,l):
    for i in 2:
        t=0
        for j in lenPattern[i]:
            for k in l:
                if re.search(patCol[i][j],strr[k]):
                    t=t+1
                     
        t=t/lenPattern[i]
        pre.append(t)
    maxx=-100
    num=0
    for i in 2:
        if pre[i]>maxx:
            maxx=pre[i]
            num=i
    #print(num+1," precision:",maxx)
    return num
p=[]
 
#1 
p.append(r"(from )?(where )(train )?(numbered |named )?([a-z]*|\d{3,4})( start | come | depart | come | leave | go | travel | pass )(from )?(to |towards )?([a-z]*)")
#2
p.append(r"(per )?(day )?(what |give |tell |how )(many )?(junction |route )?(number |name )?(train )?(available )?(travel )?(from |to )([a-z]* )(to |from )?([a-z]*)( route)?")
#3
p.append(r"(what |give |tell )(train )?(number )(train )?(named )?([a-z]*|\D{3,4})")
#4
p.append(r"(what |give |tell )(train )?(name )(train )?(numbered )?(\d{1,5})")
#5
p.append(r"(which |give |tell )(day )?(train )?(numbered |named )?([a-z]*|\d{3,4})( does not)?( go)(from |to )?([a-z]* )(to |from )?([a-z]*)")
#6
p.append(r"(which |what )(offday )(train )?(numbered |named )?([a-z]*|\d{3,4})(from |to )?([a-z]* )(to |from )?([a-z]*)")
#7
p.append(r"(give |tell |what )(name |number )?(list )?(train )([a-z]*)")
#8 
p.append(r"(what |tell |give |how )(much )?(seat )?(fare |cost |price |pay |fee |charge )(traveling |going )?([a-z]*)?")
#9
p.append(r"(what |tell |give |which )(next |previous )(station )?([a-z]*)")
#10
p.append(r"(is )?(there )?(ac | air condition )(system )?(in )?(train )(from |to )([a-z]* )(to |from )?([a-z])*")
#11 
p.append(r"(is |are )?(there )?(train )?([a-z]*)?( available )(night )?(to )?(go )?([a-z]*)")
#12
p.append(r"(when |what |give )(does |is )?([a-z]* )?(time |schedule )(of )?(the )?(train |train no |train named )?([a-z]*|\d{3})")
#13
p.append(r"(how |what )(many )?([a-z]* )?(long |time |hour )(train )?([a-z]*)( take )?(travelling )?([a-z]*)")


#what is the seat cost of train from jessore to dhaka in Subarna in s_chair

inp=input("Enter Question:")
sent= sent_tokenize(inp)
#print(sent)
for i in sent:
    words = word_tokenize(i)
print(words)
lower_tokens = [t.lower() for t in words]

# Retain alphabetic words: alpha_only
#alpha_only = [t for t in lower_tokens if t.isalpha()]

no_stops= []

# Remove all stop words: no_stops
for t in lower_tokens:
    if t in whQues or t in pre or t not in ENGLISH_STOPS:
        if t not in extra:
            no_stops.append(t)

# Instantiate the WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()

# Lemmatize all tokens into a new list: lemmatized
lemmatized = [wordnet_lemmatizer.lemmatize(t) for t in no_stops]
print(lemmatized)
# Create the bag-of-words: bow
bow = Counter(lemmatized)

# Print the 10 most common tokens 
#print(bow.most_common(10))



for t in lemmatized:
    string=string+t+" "
    #string1=string1+"("+t+" " ")"
    pattern_match.append(t)
#print('String is:' + string)
#print('Pattern is:' + string1)
#print(pattern_match)


'''
for word,pos in nltk.pos_tag(tokennns):
    nouns.append(word)
        
aa=len(nouns)
  
for t in range(aa):
    for tt in nouns[t]:
        if tt in vowels:
            nouns[t]=nouns[t].replace(tt,"")
                    
for tt in new_train_name:
    for t in nouns:
        
        if tt==t:
            if place==1:
                       wheregoescomesfromto(t,place_add[0]) 
                    else:
                        wheregoescomesfromto(t,'0')
                        
                    
    if flag==0 and flag2==0:
        print('please mention train name correctly')     
'''                

length=len(pattern_match)


for t in range(length):
    if pattern_match[t] in train_name:
        pattern_match[t]=pattern_match[t].replace(pattern_match[t],"[a-z]*|\d{3,4}")
        
    if pattern_match[t] in new_train_name: #do it
        pattern_match[t]=pattern_match[t].replace(pattern_match[t],"[a-z]*|\d{3,4}")
        
    if pattern_match[t] in place_names:
        pattern_match[t]=pattern_match[t].replace(pattern_match[t],"[a-z]*")  
        
    if pattern_match[t] in class_names:
        pattern_match[t]=pattern_match[t].replace(pattern_match[t],"[a-z]*")

cnt=0
m=0


pattern_flag=0
leave=0

if "why" in string or "buy" in string or "book" in string or "give ticket" in string:
    print(t)
    leave=1
    
if leave==1:
    print('...sorry, NOT ANSWERED...')    
  
else:
    for t in p:
        cnt=cnt+1
        if re.search(t,string):
            #print("yes matched precision 1")
            print('with Pattern:',cnt,', which is')
            #print('Actual pattern is:')
            print(t)
            store=cnt
            m=1
            answer(cnt,lemmatized)
            pattern_flag=1
            break
        
    if pattern_flag==0:
        fixed_answer(inp)
        

       


#if m==0:
    #num=precision_count(string,len(string))
    #print("Pattern ",num+1)
    #print(p[num])


