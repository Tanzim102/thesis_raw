subarna=['dhaka','biman_bandar','chittagong']
sonar_bangla=['dhaka','biman_bandar','chittagong']
mahanagar_provati=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar_godhuli=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar=["dhaka","biman_bandar","narsingdi","bhairab_bazar","ashuganj","brahmanbaria","akhaura","qosba","comilla","laksam","nangalkot","feni","chittagong"]
turna=["dhaka","biman_bandar","bhairab_bazar","ashuganj","brahmanbaria","akhaura","comilla","laksam","feni","chittagong"]



khulna_dhaka=['khulna','jessore','mobarakgong','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','mirpur','bhairamara','ishurdi','chatmohar','boral_bridge','ullapara','sm_m_monsur_ali','bbsetu_e','tangail','mirzapur','jaydebpur','biman_bandar','dhaka']
khulna_dhaka_cost=["0","90","35","15","20","15","15","15","10","10","50","25","10","20","50","45","20","20","30","30","0"]

'''
Dhaka to Khulna train ticket price varies with the quality of sitting service of each train. 
Only two trains travel on Dhaka to Khulna train route.  They are Sundarban express and Chittra Express.
On Sundarban express three types of seat services are available, Shavon Chair, Singdha, A/C Seat.
The list of this train is like: Shavon Chair- 505, Singdha- 966, A/C Seat- 1156. 
Chittra Express also has three seat services. They are Shavon Chair, Singdha, and A/C Birth.
See the price list of each: Shavon Chair- 505, Singdha- 966, A/C Birth- 1781.
'''            
            
            

def seatFair(s,a,b):
    cost=0
    count=-1
    if "sundarban" in s or "chitra" in s:
        if a in khulna_dhaka:
            if b in khulna_dhaka:
                start=khulna_dhaka.index(a)
                end=khulna_dhaka.index(b)
                print(end)
                print(start)
                if start>end:
                    ends=start
                    starts=end
                else:
                    ends=end
                    starts=start
                    print(end)
                    print(start)
                for i in khulna_dhaka_cost:
                    count=count+1
                    if count>starts:
                        cost=cost+int(i)
                        if count==ends:
                            break
 
                   
                if "ac_s" in s:
                    cost=cost+2.24*cost
                    print(cost)
                elif "s_chair" in s or 'shovon_chair' in s:
                    print(cost)
                elif "singdha" in s:
                    if a=="khulna" or a=="dhaka" and b=="khulna" or b=="dhaka":
                        print('986')
           
            
            
      
                
            else:
                print('Sorry, does not go there')
        else:
            print('Sorry, does not go there')
            
                
                

    if "ekota" in s:
        print('then')
        

# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 11:49:37 2019

@author: CITY
"""

