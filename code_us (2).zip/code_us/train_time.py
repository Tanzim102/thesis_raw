def train_time(a,b,x):
    
    print('thanks')
 
    
 