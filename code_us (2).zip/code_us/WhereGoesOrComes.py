#OK

subarna=['dhaka','biman_bandar','chittagong']
sonar_bangla=['dhaka','biman_bandar','chittagong']
mahanagar_provati=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar_godhuli=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar=["dhaka","biman_bandar","narsingdi","bhairab_bazar","ashuganj","brahmanbaria","akhaura","qosba","comilla","laksam","nangalkot","feni","chittagong"]
turna=["dhaka","biman_bandar","bhairab_bazar","ashuganj","brahmanbaria","akhaura","comilla","laksam","feni","chittagong"]

ekota=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','ishurdi_bypass','natore','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']
drutajan=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','jamtail','chatmohar','natore','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']
panchagarh=['dhaka','parbatipur','dinajpur']

doloncapa=['santaher','talora','bogura','sonatola','mohimaganj','bonar_para','gaibandha','bamondanga','kaunia','rangpur','badar_ganj','kholahati','parbatipur','cirir_bandar','dinajpur']

tista=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','pyerpur','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']
brahmaputro=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','pyerpur','nandina','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']

parabat=['dhaka','biman_bandar','bhairab_bazar','brahmanbaria','azampur','nayapara','shaistagonj','srimangal','bhanugach','kulaura','maizgaon','sylhet']
kalni=['dhaka','biman_bandar','narsingdi','bhairab_bazar','azampur','shaistagonj','srimangal','shamshernagar','kulaura','maizgaon','sylhet']
joyenteeka=['dhaka','biman_bandar','ashuganj','bhairab_bazar','azampur','mukundupur','horoshpur','montala','nayapara','shahagi_bazar','shaistagonj','srimangal','bhanugach','kulaura','maizgaon','sylhet']
upaban=['dhaka','biman_bandar','narsingdi','bhairab_bazar','azampur','shaistagonj','srimangal','bhanugach','shamshernagar','kulaura','maizgaon','sylhet']

upakul=['dhaka','biman_bandar','narsingdi','bhairab_bazar','ashuganj','brahmanbaria','akhaura','qosba','comilla','laksam','nathar_patua','sonaimuri','bojra','choumuhani','maijdi_court','noakhali']

korotaya=['santaher','bogura','sonatola','bonar_para','gaibandha','bamondanga','pirgacha','kaunia','lalmonirhat','aditmari','tushvandar','hatibandha','patgram','burimari']

paharika=['chittagong','feni','nangalkot','laksam','comilla','qosba','akhaura','horoshpur','nayapara','shaistagonj','srimangal','bhanugach','shamshernagar','kulaura','maizgaon','sylhet']
udayan=['chittagong','feni','laksam','comilla','akhaura','shaistagonj','srimangal','shamshernagar','kulaura','maizgaon','sylhet']

meghna=['chittagong','feni','nangalkot','laksam','chitosi_road','meher','hajiganj','modhu_road','chandpur_court','chandpur']

augnibina=['dhaka','biman_bandar','gafargaon','mymensingh','jamalpur','jamalpur_town','sarisha_bari','tarakandi']
jamuna=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','jamalpur','jamalpur_town','sarisha_bari','tarakandi']
 
egarosindur_provati=['dhaka','biman_bandar','narsingdi','bhairab_bazar','kuliarchar','bajipur','sararchar','manik_khali','gachihata','kishoreganj']
kishoreganj=['dhaka','biman_bandar','narsingdi','methikanda','bhairab_bazar','kuliarchar','bajipur','sararchar','manik_khali','gachihata','kishoreganj']
egarosindur_godhuli=['dhaka','biman_bandar','narsingdi','methikanda','bhairab_bazar','kuliarchar','bajipur','sararchar','manik_khali','gachihata','kishoreganj']

lalmoni=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','ullapara','boral_bridge','agimnagar','natore','santaher','bogura','sonatola','bonar_para','gaibandha','bamondanga','pirgacha','kaunia','lalmonirhat']

rangpur=['dhaka','biman_bandar','bbsetu_e','chatmohar','natore','santaher','bogura','bonar_para','gaibandha','bamondanga','pirgacha','kaunia','kurigram','rangpur']
kurigram=['dhaka','biman_bandar','madhnagar','santaher','joypurhat','parbatipur','badar_ganj','rangpur']

mohonganj=['dhaka','biman_bandar','gafargaon','mymensingh','gouripur_myn','shemganj','netrokona','thakurakona','barhatta','mohonganj']
haowr=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','gouripur_myn','shemganj','netrokona','thakurakona','barhatta','mohonganj']

bijoy=['chittagong','bhatiary','feni','laksam','comilla','akhaura','bhairab_bazar','kishoreganj','gouripur_myn','mymensingh']
 
kopotakha=['khulna','noapara','jessore','mobarakgong','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','mirpur','bhairamara','pakshi','ishurdi','agimnagar','rajshahi']
shagordari=['khulna','noapara','jessore','mobarakgong','court_chandpur','safdarpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','pakshi','ishurdi','agimnagar','rajshahi']

chitra=['khulna','noapara','jessore','mobarakgong','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','mirpur','bhairamara','ishurdi','chatmohar','boral_bridge','ullapara','sm_m_monsur_ali','bbsetu_e','tangail','mirzapur','jaydebpur','biman_bandar','dhaka']
sundarban=['khulna','daulatpur','noapara','jessore','mobarakgong','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','ishurdi','chatmohar','boral_bridge','ullapara','jamtail','sm_m_monsur_ali','bbsetu_e','tangail','mirzapur','jaydebpur','biman_bandar','dhaka']

rupsa=['khulna','noapara','jessore','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','pakshi','ishurdi','natore','ahasangang','santaher','accalpur','joypurhat','birampur','phulbari','parbatipur','saidpur','neelfamari','chilahati']
seemanta=['khulna','daulatpur','noapara','jessore','darsana_halt','chuadanga','poradaha','bhairamara','ishurdi','natore','santaher','accalpur','joypurhat','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']

borendra=['rajshahi','abdulpur','natore','ahasangang','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']
titumir=['rajshahi','abdulpur','natore','ahasangang','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']

banalata=['rajshahi','dhaka']
silk_city=['rajshahi','abdulpur','ishurdi','ishurdi_bypass','chatmohar','boral_bridge','ullapara','jamtail','sm_m_monsur_ali','bbsetu_e','tangail','mirzapur','jaydebpur','biman_bandar','dhaka']
padma=['rajshahi','shordha_road','abdulpur','ishurdi','ishurdi_bypass','chatmohar','boral_bridge','ullapara','sm_m_monsur_ali','bbsetu_e','tangail','jaydebpur','biman_bandar','dhaka']
dhumkatu=['rajshahi','abdulpur','arani','chatmohar','boral_bridge','sm_m_monsur_ali','bbsetu_e','jaydebpur','biman_bandar','dhaka']

modhumati=['rajshahi','ishurdi','pakshi','bhairamara','mirpur','poradaha','kustia','kustia_court','kumarkhali','khoksa','pangsha','kalukhali','rajbari','goalandaghat']

nelsagore=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','muladuli','natore','ahasangang','santaher','accalpur','joypurhat','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']

sirajganj=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','jamtail','sirajganj_bazar','sirajganj']
 
bandhan=['kolkata','khulna']
moitree=['kolkata','dhaka_cantt']

faridpur=['faridpur','rajbari']

kalukhali_vatiap=['vatiapara_ghat','goalondho']


def wheregoescomesfromto(t,temp):
    
    if t=='701' or t=='702' or t=='subarna' or t=='sbrn':
        if temp=='0':
            print('subarna train goes to these places:')
            for t in subarna:
                print(t)
        elif temp in subarna:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='703' or t=='mahanagar_godhuli' or t=='mngr_gdl':
        if temp=='0':
            print('mahanagar_godhuli train goes to these places:')
            for t in mahanagar_godhuli:
                print(t)     
        elif temp in mahanagar_godhuli:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='704' or t=='mahanagar_provati' or t=='mngr_prvt':
        if temp=='0':
            print('mahanagar_provati train goes to these places:')
            for t in mahanagar_provati:
                print(t)
        elif temp in mahanagar_provati:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='705' or t=='706' or t=='ekota' or t=='kt':
        if temp=='0':
            print('ekota train goes to these places:')
            for t in ekota:
                print(t)      
        elif temp in ekota:
            if temp=='dhaka':
                print('Dinajpur')
            elif temp=='dinajpur':
                print('Dhaka')
            else:
                print('on Dhaka-Dinajpur route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='707' or t=='708' or t=='tista' or t=='tst':
        if temp=='0':
            print('tista train goes to these places:')
            for t in tista:
                print(t)
        elif temp in tista:
            if temp=='dhaka':
                print('Dewanganj_bazar')
            elif temp=='dewanganj_bazar':
                print('Dhaka')
            else:
                print('on Dhaka-Dewanganj_bazar route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='709' or t=='710' or t=='parabat' or t=='prbt':
        if temp=='0':
            print('parabat train goes to these places:')
            for t in parabat:
                print(t)    
        elif temp in parabat:
            if temp=='dhaka':
                print('Sylhet')
            elif temp=='sylhet':
                print('Dhaka')
            else:
                print('on Dhaka-Sylhet route')
        else:
            print('Sorry does not go there')
                        

    elif t=='711' or t=='712' or t=='upakul' or t=='pkl':
        if temp=='0':
            print('upakul train goes to these places:')
            for t in upakul:
                print(t)
        elif temp in upakul:
            if temp=='dhaka':
                print('noakhali')
            elif temp=='noakhali':
                print('Dhaka')
            else:
                print('on Dhaka-Noakhali route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='713' or t=='714' or t=='korotaya' or t=='krty':
        if temp=='0':
            print('korotaya train goes to these places:')
            for t in korotaya:
                print(t)      
        elif temp in korotaya:
            if temp=='santaher':
                print('burimari')
            elif temp=='burimari':
                print('santaher')
            else:
                print('on santaher-burimari route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='715' or t=='716' or t=='kopotakha' or t=='kptk':
        if temp=='0':
            print('kopotakha train goes to these places:')
            for t in kopotakha:
                print(t)
        elif temp in kopotakha:
            if temp=='khulna':
                print('Rajshahi')
            elif temp=='rajshahi':
                print('khulna')
            else:
                print('on Khulna-Rajshahi route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='717' or t=='718' or t=='joyenteeka' or t=='jyntk':
        if temp=='0':
            print('joyenteeka train goes to these places:')
            for t in joyenteeka:
                print(t)     
        elif temp in joyenteeka:
            if temp=='dhaka':
                print('Sylhet')
            elif temp=='sylhet':
                print('Dhaka')
            else:
                print('on Dhaka-Sylhet route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='719' or t=='720' or t=='paharika' or t=='prk':
        if temp=='0':
            print('paharika train goes to these places:')
            for t in paharika:
                print(t)
        elif temp in paharika:
            if temp=='sylhet':
                print('Chittagong')
            elif temp=='chittagong':
                print('sylhet')
            else:
                print('on Sylhet-Chittagong route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='721' or t=='722' or t=='mahanagar' or t=='mngr':
        if temp=='0':
            print('Mahanagar train goes to these places:')
            for t in mahanagar:
                print(t)      
        elif temp in mahanagar:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')      
            
            
            
            
    elif t=='723' or t=='724' or t=='udayan' or t=='dyn':
        if temp=='0':
            print('udayan train goes to these places:')
            for t in udayan:
                print(t)
        elif temp in udayan:
            if temp=='sylhet':
                print('Chittagong')
            elif temp=='chittagong':
                print('sylhet')
            else:
                print('on Sylhet-Chittagong route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='725' or t=='726' or t=='sundarban' or t=='sndrbn':
        if temp=='0':
            print('sundarban train goes to these places:')
            for t in sundarban:
                print(t)      
        elif temp in sundarban:
            if temp=='dhaka':
                print('Khulna')
            elif temp=='khulna':
                print('Dhaka')
            else:
                print('on Dhaka-khulna route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='727' or t=='728' or t=='rupsa' or t=='rps':
        if temp=='0':
            print('rupsa train goes to these places:')
            for t in rupsa:
                print(t)
        elif temp in rupsa:
            if temp=='chilahati':
                print('khulna')
            elif temp=='khulna':
                print('chilahati')
            else:
                print('on khulna-chilahati route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='729' or t=='730' or t=='meghna' or t=='mgn':
        if temp=='0':
            print('meghna train goes to these places:')
            for t in meghna:
                print(t)      
        elif temp in meghna:
            if temp=='chandpur':
                print('Chittagong')
            elif temp=='chittagong':
                print('chandpur')
            else:
                print('on Chittagong-Chandpur route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='731' or t=='732' or t=='borendra' or t=='brndr':
        if temp=='0':
            print('borendra train goes to these places:')
            for t in borendra:
                print(t)
        elif temp in borendra:
            if temp=='chilahati':
                print('rajshahi')
            elif temp=='rajshahi':
                print('chilahati')
            else:
                print('on rajshahi-chilahati route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='733' or t=='734' or t=='titumir' or t=='ttmr':
        if temp=='0':
            print('titumir train goes to these places:')
            for t in titumir:
                print(t)      
        elif temp in titumir:
            if temp=='chilahati':
                print('rajshahi')
            elif temp=='rajshahi':
                print('chilahati')
            else:
                print('on rajshahi-chilahati route')
        else:
            print('Sorry does not go there')
                        

    elif t=='735' or t=='736' or t=='augnibina' or t=='agnbn':
        if temp=='0':
            print('augnibina train goes to these places:')
            for t in augnibina:
                print(t)
        elif temp in augnibina:
            if temp=='dhaka':
                print('tarakandi')
            elif temp=='tarakandi':
                print('Dhaka')
            else:
                print('on Dhaka-Tarakandi route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='737' or t=='738' or t=='egarosindur_provati' or t=='grsndr_prvt':
        if temp=='0':
            print('egarosindur_provati train goes to these places:')
            for t in egarosindur_provati:
                print(t)      
        elif temp in egarosindur_provati:
            if temp=='dhaka':
                print('kishoreganj')
            elif temp=='kishoreganj':
                print('Dhaka')
            else:
                print('on Dhaka-Kishoreganj route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='739' or t=='740' or t=='upaban' or t=='pbn':
        if temp=='0':
            print('upaban train goes to these places:')
            for t in upaban:
                print(t)
        elif temp in upaban:
            if temp=='dhaka':
                print('Sylhet')
            elif temp=='sylhet':
                print('Dhaka')
            else:
                print('on Dhaka-Sylhet route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='741' or t=='742' or t=='turna' or t=='trn':
        if temp=='0':
            print('turna train goes to these places:')
            for t in turna:
                print(t)      
        elif temp in turna:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='743' or t=='744' or t=='brahmaputro' or t=='brmptr':
        if temp=='0':
            print('brahmaputro train goes to these places:')
            for t in brahmaputro:
                print(t)
        elif temp in brahmaputro:
            if temp=='dhaka':
                print('Dewanganj_bazar')
            elif temp=='dewanganj_bazar':
                print('Dhaka')
            else:
                print('on Dhaka-Dewanganj_bazar route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='745' or t=='746' or t=='jamuna' or t=='jmn':
        if temp=='0':
            print('jamuna train goes to these places:')
            for t in jamuna:
                print(t)     
        elif temp in jamuna:
            if temp=='dhaka':
                print('tarakandi')
            elif temp=='tarakandi':
                print('Dhaka')
            else:
                print('on Dhaka-Tarakandi route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='747' or t=='748' or t=='seemanta' or t=='smnt':
        if temp=='0':
            print('seemanta train goes to these places:')
            for t in seemanta:
                print(t)
        elif temp in seemanta:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='749' or t=='750' or t=='egarosindur_godhuli' or t=='grsndr_gdl':
        if temp=='0':
            print('egarosindur_godhuli train goes to these places:')
            for t in egarosindur_godhuli:
                print(t)      
        elif temp in egarosindur_godhuli:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='751' or t=='752' or t=='lalmoni' or t=='llmn':
        if temp=='0':
            print('lalmoni train goes to these places:')
            for t in lalmoni:
                print(t)
        elif temp in lalmoni:
            if temp=='chilahati':
                print('khulna')
            elif temp=='khulna':
                print('chilahati')
            else:
                print('on khulna-chilahati route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='753' or t=='754' or t=='silk_city' or t=='slk_cty':
        if temp=='0':
            print('silk_city train goes to these places:')
            for t in silk_city:
                print(t)    
        elif temp in silk_city:
            if temp=='dhaka':
                print('rajshahi')
            elif temp=='rajshahi':
                print('Dhaka')
            else:
                print('on Dhaka-Rajshahi route')
        else:
            print('Sorry does not go there')
                        

    elif t=='755' or t=='756' or t=='modhumati' or t=='mdmt':
        if temp=='0':
            print('modhumati train goes to these places:')
            for t in modhumati:
                print(t)
        elif temp in modhumati:
            if temp=='goalandaghat':
                print('rajshahi')
            elif temp=='rajshahi':
                print('goalandaghat')
            else:
                print('on Goalandaghat-Rajshahi route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='757' or t=='758' or t=='drutajan' or t=='drtjn':
        if temp=='0':
            print('drutajan train goes to these places:')
            for t in drutajan:
                print(t)      
        elif temp in drutajan:
            if temp=='dhaka':
                print('dinajpur')
            elif temp=='dinajpur':
                print('Dhaka')
            else:
                print('on Dhaka-Dinajpur route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='759' or t=='760' or t=='padma' or t=='pdm':
        if temp=='0':
            print('padma train goes to these places:')
            for t in padma:
                print(t)
        elif temp in padma:
            if temp=='dhaka':
                print('rajshahi')
            elif temp=='rajshahi':
                print('Dhaka')
            else:
                print('on Dhaka-Rajshahi route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='761' or t=='762' or t=='shagordari' or t=='sgrdr':
        if temp=='0':
            print('shagordari train goes to these places:')
            for t in shagordari:
                print(t)     
        elif temp in shagordari:
            if temp=='khulna':
                print('rajshahi')
            elif temp=='rajshahi':
                print('khulna')
            else:
                print('on Khulna-Rajshahi route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='763' or t=='764' or t=='chitra' or t=='ctr':
        if temp=='0':
            print('chitra train goes to these places:')
            for t in chitra:
                print(t)
        elif temp in chitra:
            if temp=='dhaka':
                print('khulna')
            elif temp=='khulna':
                print('Dhaka')
            else:
                print('on Dhaka-Khulna route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='765' or t=='766' or t=='nelsagore' or t=='nlsgr':
        if temp=='0':
            print('nelsagore train goes to these places:')
            for t in nelsagore:
                print(t)      
        elif temp in nelsagore:
            if temp=='dhaka':
                print('chilahati')
            elif temp=='chilahati':
                print('Dhaka')
            else:
                print('on Dhaka-Chilahati route')
        else:
            print('Sorry does not go there')      
            
            
            
            
    elif t=='767' or t=='768' or t=='doloncapa' or t=='dlncp':
        if temp=='0':
            print('doloncapa train goes to these places:')
            for t in doloncapa:
                print(t)
        elif temp in doloncapa:
            if temp=='santaher':
                print('dinajpur')
            elif temp=='dinajpur':
                print('santaher')
            else:
                print('on santaher-dinajpur route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='769' or t=='770' or t=='dhumkatu' or t=='dmkt':
        if temp=='0':
            print('dhumkatu train goes to these places:')
            for t in dhumkatu:
                print(t)      
        elif temp in dhumkatu:
            if temp=='dhaka':
                print('rajshahi')
            elif temp=='rajshahi':
                print('Dhaka')
            else:
                print('on Dhaka-Rajshahi route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='771' or t=='772' or t=='rangpur' or t=='rngpr':
        if temp=='0':
            print('rangpur train goes to these places:')
            for t in rangpur:
                print(t)
        elif temp in rangpur:
            if temp=='dhaka':
                print('rangpur')
            elif temp=='rangpur':
                print('Dhaka')
            else:
                print('on Dhaka-Rangpur route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='773' or t=='774' or t=='kalni' or t=='kln':
        if temp=='0':
            print('kalni train goes to these places:')
            for t in kalni:
                print(t)      
        elif temp in kalni:
            if temp=='dhaka':
                print('sylhet')
            elif temp=='sylhet':
                print('Dhaka')
            else:
                print('on Dhaka-Sylhet route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='775' or t=='776' or t=='sirajganj' or t=='srjgnj':
        if temp=='0':
            print('sirajganj train goes to these places:')
            for t in sirajganj:
                print(t)
        elif temp in sirajganj:
            if temp=='dhaka':
                print('sirajganj')
            elif temp=='sirajganj':
                print('Dhaka')
            else:
                print('on Dhaka-Sirajganj route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='777' or t=='778' or t=='haowr' or t=='wr':
        if temp=='0':
            print('haowr train goes to these places:')
            for t in haowr:
                print(t)      
        elif temp in haowr:
            if temp=='dhaka':
                print('mohonganj')
            elif temp=='mohonganj':
                print('Dhaka')
            else:
                print('on Dhaka-Mohonganj route')
        else:
            print('Sorry does not go there')
            
            
                        
    elif t=='779' or t=='780' or t=='kalukhali_vatiap' or t=='klkl_vtp':
        if temp=='0':
            print('kalukhali_vatiap train goes to these places:')
            for t in kalukhali_vatiap:
                print(t)
        elif temp in kalukhali_vatiap:
            if temp=='vatiapara_ghat':
                print('goalondho')
            elif temp=='goalondho':
                print('vatiapara_ghat')
            else:
                print('on vatiapara_ghat-goalondho route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='781' or t=='782' or t=='kishoreganj' or t=='ksrgnj':
        if temp=='0':
            print('kishoreganj train goes to these places:')
            for t in kishoreganj:
                print(t)
        elif temp in kishoreganj:
            if temp=='dhaka':
                print('kishoreganj')
            elif temp=='kishoreganj':
                print('Dhaka')
            else:
                print('on Dhaka-Kishoreganj route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='783' or t=='784' or t=='faridpur' or t=='frdpr':
        if temp=='0':
            print('faridpur train goes to these places:')
            for t in faridpur:
                print(t)      
        elif temp in faridpur:
            if temp=='rajbari':
                print('faridpur')
            elif temp=='faridpur':
                print('rajbari')
            else:
                print('on Rajbari-Faridpur route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='785' or t=='786' or t=='bijoy' or t=='bjy':
        if temp=='0':
            print('faridpur train goes to these places:')
            for t in faridpur:
                print(t)
        elif temp in faridpur:
            if temp=='mymensingh':
                print('Chittagong')
            elif temp=='chittagong':
                print('mymensingh')
            else:
                print('on Mymensingh-Chittagong route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='787' or t=='788' or t=='sonar_bangla' or t=='snr_bngl':
        if temp=='0':
            print('sonar_bangla train goes to these places:')
            for t in sonar_bangla:
                print(t)      
        elif temp in sonar_bangla:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='789' or t=='790' or t=='mohonganj' or t=='mngnj':
        if temp=='0':
            print('mohonganj train goes to these places:')
            for t in mohonganj:
                print(t)
        elif temp in mohonganj:
            if temp=='dhaka':
                print('mohonganj')
            elif temp=='mohonganj':
                print('Dhaka')
            else:
                print('on Dhaka-Mohonganj route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='3107' or t=='3108' or t=='3109' or t=='3110' or t=='moitree' or t=='mtr':
        if temp=='0':
            print('moitree train goes to these places:')
            for t in moitree:
                print(t)      
        elif temp in moitree:
            if temp=='dhaka_cantt':
                print('kolkata')
            elif temp=='kolkata':
                print('dhaka_cantt')
            else:
                print('on dhaka_cantt-kolkata route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='3129' or t=='3130' or t=='bandhan' or t=='bndn':
        if temp=='0':
            print('bandhan train goes to these places:')
            for t in bandhan:
                print(t)
        elif temp in bandhan:
            if temp=='khulna':
                print('kolkata')
            elif temp=='kolkata':
                print('khulna')
            else:
                print('on khulna-kolkata route')
        else:
            print('Sorry does not go there')
            
            
            
    else:
        print('Invalid')