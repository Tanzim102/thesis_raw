final_destination=['dhaka', 'chittagong', 'santaher', 'rajshahi', 'khulna', 'koltaka', 'faridpur', 'rajbari', 'dinajpur',
                   'dewanganj_bazar', 'chandpur', 'tarakandi', 'sylhet', 'noakhali', 'burimari','kishoreganj', 'rangpur',
                   'mohonganj', 'lalmonirhat', 'mymensingh', 'chilahati', 'goalandaghat', 'sirajganj']


dhk_ctg=['ac_s','ac_b','f_seat','f_berth','snigdha','s_chair']
subarna=['dhaka','biman_bandar','chittagong']
subarna_cost=['0','0','0','0','725','380']
subarna_raw_cost=['0','380']
sonar_bangla=['dhaka','biman_bandar','chittagong']
sonar_bangla_cost=['1100','0','800','0','1000','600']
sonar_bangla_raw_cost=['0','600']
mahanagar_provati=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar_provati_cost=['788','0','460','0','656','345']
mahanagar_provati_raw_cost=["0","75","40","15","45","20","25","15","110"]
mahanagar_godhuli=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar_godhuli_cost=['788','0','460','0','656','345']
mahanagar_godhuli_raw_cost=["0","75","40","15","45","20","25","15","110"]
mahanagar=["dhaka","biman_bandar","narsingdi","bhairab_bazar","ashuganj","brahmanbaria","akhaura","qosba","comilla","laksam","nangalkot","feni","chittagong"]
mahanagar_cost=['0','1229','0','0','656','345']
mahanagar_raw_cost=["0","75","40","15","45","20","25","15","110"]
turna=["dhaka","biman_bandar","bhairab_bazar","ashuganj","brahmanbaria","akhaura","comilla","laksam","feni","chittagong"]
turna_cost=['0','1229','0','735','656','345']
turna_raw_cost=["0","75","40","0","15","45","20","40","110"]


dhk_dinaj=['ac_s','ac_b','snigdha','s_chair']
ekota=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','ishurdi_bypass','natore','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']
ekota_cost=['0','1649','892','465']
ekota_raw_cost=['0','50','65','20','90','65','30','40','15','15','5','20','10','15','25','0']
drutajan=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','jamtail','chatmohar','natore','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']
drutajan_cost=['1070','0','892','465']
drutajan_raw_cost=['0','50','65','20','90','65','30','40','15','15','5','20','10','15','25','0']
panchagarh=['dhaka','biman_bandar','parbatipur','dinajpur']
panchagarh_cost=['1070','0','892','465']
panchagarh_raw_cost=['0','440','25']


san_dinaj=['s_chair']
doloncapa=['santaher','talora','bogura','sonatola','mohimaganj','bonar_para','gaibandha','bamondanga','kaunia','rangpur','badar_ganj','kholahati','parbatipur','cirir_bandar','dinajpur']
doloncapa_cost=['255']
doloncapa_raw_cost=['50','5','30','5','10','20','25','45','0','20','20','0','15','10']


dhk_dewan=['ac_s','f_seat','shovan','snigdha','s_chair']
tista=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','pyerpur','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']
tista_cost=['512','300','0','426','225']
tista_raw_cost=['0','50','55','35','25','25','0','15','20','30']
brahmaputro=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']
brahmaputro_cost=['0','300','185','0','225']
brahmaputro_raw_cost=['0','50','55','35','50','0','15','20','30']


dhk_syl=['ac_s','ac_b','f_seat','f_berth','snigdha','s_chair','f_chair','shovan']
parabat=['dhaka','biman_bandar','bhairab_bazar','brahmanbaria','azampur','nayapara','shaistagonj','srimangal','bhanugach','kulaura','maizgaon','sylhet']
parabat_cost=['736','0','425','0','610','320','0','0']
parabat_raw_cost=['0','105','40','20','30','20','25','10','30','40','0']
kalni=['dhaka','biman_bandar','bhairab_bazar','azampur','shaistagonj','srimangal','shamshernagar','kulaura','sylhet']
kalni_cost=['0','0','0','0','0','320','425','265']
kalni_raw_cost=['0','105','60','50','25','25','15','40']
joyenteeka=['dhaka','biman_bandar','ashuganj','azampur','mukundupur','horoshpur','montala','nayapara','shahagi_bazar','shaistagonj','srimangal','bhanugach','kulaura','maizgaon','sylhet']
joyenteeka_cost=['736','0','425','0','0','320','425','265']
joyenteeka_raw_cost=['0','130','35','5','10','5','10','10','10','25','10','30','40','0']
upaban=['dhaka','biman_bandar','bhairab_bazar','azampur','shaistagonj','srimangal','shamshernagar','kulaura','maizgaon','sylhet']
upaban_cost=['0','1149','0','690','0','320','425','265']
upaban_raw_cost=['0','105','60','50','25','25','15','40','0']

dhk_noa=['ac_s','f_seat','shovan','s_chair']
upakul=['dhaka','biman_bandar','bhairab_bazar','nathar_patua','sonaimuri','bojra','choumuhani','maijdi_court','noakhali']
upakul_cost=['627','365','230','275']
upakul_raw_cost=['0','115','135','15','0','0','0','0']

san_buri=['shovan']
korotaya=['santaher','bogura','sonatola','bonar_para','gaibandha','bamondanga','pirgacha','kaunia','lalmonirhat','aditmari','tushvandar','hatibandha','patgram','burimari']
korotaya_cost=['220']

ctg_syl=['f_seat','f_berth','snigdha','s_chair','shovan']
paharika=['chittagong','feni','laksam','comilla','shaistagonj','srimangal','shamshernagar','kulaura','maizgaon','sylhet']
paharika_cost=['500','0','719','375','315']
paharika_raw_cost=['110','40','20','100','30','15','20','40','0']
udayan=['chittagong','feni','laksam','comilla','shaistagonj','srimangal','shamshernagar','kulaura','sylhet']
udayan_cost=['0','795','719','375','315']
udayan_raw_cost=['110','40','20','100','30','15','20','40']

ctg_chand=['f_chair','f_seat','shovan','s_chair']
meghna=['chittagong','meher','hajiganj','modhu_road','chandpur_court','chandpur']
meghna_cost=['260','260','165','195']
meghna_raw_cost=['170','25','0','0','0']

dhk_tara=['f_seat','shovan','s_chair']
augnibina=['dhaka','biman_bandar','gafargaon','mymensingh','jamalpur','jamalpur_town','sarisha_bari','tarakandi']
augnibina_cost=['300','190','225']
augnibina_raw_cost=['0','105','35','50','0','35','0']
jamuna=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','jamalpur','jamalpur_town','sarisha_bari','tarakandi']
jamuna_cost=['300','190','225']
jamuna_raw_cost=['0','50','55','35','50','0','35','0']


dhk_kisore=['f_chair','f_seat','shovan','s_chair','snigdha']
egarosindur_provati=['dhaka','biman_bandar','bhairab_bazar','bajipur','sararchar','kishoreganj']
egarosindur_provati_cost=['200','200','125','150','0']
egarosindur_provati_raw_cost=['0','105','20','5','20']
kishoreganj=['dhaka','biman_bandar','methikanda','bhairab_bazar','bajipur','sararchar','kishoreganj']
kishoreganj_cost=['200','200','125','150','288']
kishoreganj_raw_cost=['0','75','40','20','5','20']
egarosindur_godhuli=['dhaka','biman_bandar','methikanda','bhairab_bazar','bajipur','sararchar','kishoreganj']
egarosindur_godhuli_cost=['200','200','125','150','0']
egarosindur_godhuli_raw_cost=['0','75','40','20','5','20']


dhk_lal=['ac_b','s_chair','snigdha']
lalmoni=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','ullapara','boral_bridge','agimnagar','natore','santaher','bogura','sonatola','bonar_para','gaibandha','bamondanga','kaunia','lalmonirhat']
lalmoni_cost=['1781','966','505']
lalmoni_raw_cost=['0','50','65','20','90','20','20','35','20','40','35','25','10','15','20','40','0']


dhk_rang=['ac_s','ac_b','s_chair','snigdha']
rangpur=['dhaka','biman_bandar','bbsetu_e','chatmohar','natore','santaher','bogura','bonar_para','gaibandha','bamondanga','pirgacha','kaunia','kurigram','rangpur']
rangpur_cost=['1162','0','505','966']
rangpur_raw_cost=['0','135','135','50','40','35','35','15','20','15','10','10','5']
kurigram=['dhaka','biman_bandar','madhnagar','santaher','joypurhat','parbatipur','badar_ganj','rangpur']
kurigram_cost=['0','1672','470','903']
kurigram_raw_cost=['0','335','25','30','50','15','50']

dhk_mohon=['ac_b','f_berth','f_seat','shovan','snigdha','s_chair']
mohonganj=['dhaka','biman_bandar','gafargaon','mymensingh','gouripur_myn','shemganj','netrokona','thakurakona','barhatta','mohonganj']
mohonganj_cost=['0','105','35','25','15','15','0','25','0']
mohonganj_raw_cost=[]
haowr=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','gouripur_myn','shemganj','netrokona','thakurakona','barhatta','mohonganj']
haowr_cost=['809','490','0','185','0','220']
haowr_raw_cost=['0','50','55','35','25','15','15','0','25','0']
#CHECKED


def seatFair(a,b,c,t):
    cost=0
    count=-1
    
        
    if t=='701' or t=='702' or t=='subarna' or t=='sbrn':
        if c in dhk_ctg:
            if a in final_destination and b in final_destination:
                if a in subarna and b in subarna:
                    s=dhk_ctg.index(c)
                    w=subarna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in subarna and b in subarna:
                    start=subarna.index(a)
                    end=subarna.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in subarna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 

                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
    elif t=='787' or t=='788' or t=='sonar_bangla' or t=='snr_bngl':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in sonar_bangla and b in sonar_bangla:
                    s=dhk_ctg.index(c)
                    w=sonar_bangla_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in sonar_bangla and b in sonar_bangla:
                    start=sonar_bangla.index(a)
                    end=sonar_bangla.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in sonar_bangla_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)

                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
        else:
            print('this type of class service is not available for this train')
                    
                    
        
    elif t=='704' or t=='mahanagar_provati' or t=='mngr_prvt':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in mahanagar_provati and b in mahanagar_provati:
                    s=dhk_ctg.index(c)
                    w=mahanagar_provati_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mahanagar_provati and b in mahanagar_provati:
                    start=mahanagar_provati.index(a)
                    end=mahanagar_provati.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mahanagar_provati_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
    elif t=='703' or t=='mahanagar_godhuli' or t=='mngr_gdl':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in mahanagar_godhuli and b in mahanagar_godhuli:
                    s=dhk_ctg.index(c)
                    w=mahanagar_godhuli_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mahanagar_godhuli and b in mahanagar_godhuli:
                    start=mahanagar_godhuli.index(a)
                    end=mahanagar_godhuli.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mahanagar_godhuli_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
                    
        else:
            print('this type of class service is not available for this train')
                    
                    
                 
    elif t=='741' or t=='742' or t=='turna' or t=='trn':
        if c in dhk_ctg:
                
            if a in final_destination and b in final_destination:
                if a in turna and b in turna:
                    s=dhk_ctg.index(c)
                    w=turna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in turna and b in turna:
                    start=turna.index(a)
                    end=turna.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in turna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
                    
        else:
            print('this type of class service is not available for this train')
                    
                        

    elif t=='721' or t=='722' or t=='mahanagar' or t=='mngr':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in mahanagar and b in mahanagar:
                    s=dhk_ctg.index(c)
                    w=mahanagar_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mahanagar and b in mahanagar:
                    start=mahanagar.index(a)
                    end=mahanagar.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mahanagar_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
        else:
            print('this type of class service is not available for this train')
                    
                    
                    
                    
        
    elif t=='705' or t=='706' or t=='ekota' or t=='kt':
        if c in dhk_dinaj:
            
            if a in final_destination and b in final_destination:
                if a in ekota and b in ekota:
                    s=dhk_dinaj.index(c)
                    w=ekota_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in ekota and b in ekota:
                    start=ekota.index(a)
                    end=ekota.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in ekota_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                        
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
            
            
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='757' or t=='758' or t=='drutajan' or t=='drtjn':
        if c in dhk_dinaj:

            if a in final_destination and b in final_destination:
                if a in drutajan and b in drutajan:
                    s=dhk_dinaj.index(c)
                    w=drutajan_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in drutajan and b in drutajan:
                    start=drutajan.index(a)
                    end=drutajan.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in drutajan_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')            
            
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='793' or t=='794' or t=='panchagarh' or t=='pncgr':
        if c in dhk_dinaj:
            
            if a in final_destination and b in final_destination:
                if a in panchagarh and b in panchagarh:
                    s=dhk_dinaj.index(c)
                    w=panchagarh_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in panchagarh and b in panchagarh:
                    start=panchagarh.index(a)
                    end=panchagarh.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in panchagarh_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')            
        else:
            print('this type of class service is not available for this train')
 



    elif t=='767' or t=='768' or t=='doloncapa' or t=='dlncp':
        if c in san_dinaj:
        
            if a in final_destination and b in final_destination:
                if a in doloncapa and b in doloncapa:
                    s=san_dinaj.index(c)
                    w=doloncapa_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in doloncapa and b in doloncapa:
                    start=doloncapa.index(a)
                    end=doloncapa.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in doloncapa_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')     
            
            
        else:
            print('this type of class service is not available for this train')
            
   
    
    elif t=='707' or t=='708' or t=='tista' or t=='tst':
        if c in dhk_dewan:
            if a in final_destination and b in final_destination:
                if a in tista and b in tista:
                    s=dhk_dewan.index(c)
                    w=tista_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in tista and b in tista:
                    start=tista.index(a)
                    end=tista.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in tista_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
    elif t=='743' or t=='744' or t=='brahmaputro' or t=='brmptr':
        if c in dhk_dewan:
            if a in final_destination and b in final_destination:
                if a in brahmaputro and b in brahmaputro:
                    s=dhk_dewan.index(c)
                    w=brahmaputro_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in brahmaputro and b in brahmaputro:
                    start=brahmaputro.index(a)
                    end=brahmaputro.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in brahmaputro_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
            
        else:
            print('this type of class service is not available for this train')
            
            
            
           
    elif t=='709' or t=='710' or t=='parabat' or t=='prbt':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in parabat and b in parabat:
                    s=dhk_syl.index(c)
                    w=parabat_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in parabat and b in parabat:
                    start=parabat.index(a)
                    end=parabat.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in parabat_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
          
            
            
    elif t=='717' or t=='718' or t=='joyenteeka' or t=='jyntk':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in joyenteeka and b in joyenteeka:
                    s=dhk_syl.index(c)
                    w=joyenteeka_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in joyenteeka and b in joyenteeka:
                    start=joyenteeka.index(a)
                    end=joyenteeka.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in joyenteeka_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='773' or t=='774' or t=='kalni' or t=='kln':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in kalni and b in kalni:
                    s=dhk_syl.index(c)
                    w=kalni_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in kalni and b in kalni:
                    start=kalni.index(a)
                    end=kalni.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in kalni_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='739' or t=='740' or t=='upaban' or t=='pbn':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in upaban and b in upaban:
                    s=dhk_syl.index(c)
                    w=upaban_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in upaban and b in upaban:
                    start=upaban.index(a)
                    end=upaban.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in upaban_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')



    
    elif t=='711' or t=='712' or t=='upakul' or t=='pkl':
        if c in dhk_noa:
            
            if a in final_destination and b in final_destination:
                if a in upakul and b in upakul:
                    s=dhk_noa.index(c)
                    w=upakul_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in upakul and b in upakul:
                    start=upakul.index(a)
                    end=upakul.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in upakul_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='713' or t=='714' or t=='korotaya' or t=='krty':
        if c in san_buri:
            
            if a in final_destination and b in final_destination:
                if a in upaban and b in upaban:
                    s=san_buri.index(c)
                    w=upaban_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                print('sorry no service recored')
                         
        else:
            print('this type of class service is not available for this train')
            
                      
            
    elif t=='719' or t=='720' or t=='paharika' or t=='prk':
        if c in ctg_syl:
            
            if a in final_destination and b in final_destination:
                if a in paharika and b in paharika:
                    s=ctg_syl.index(c)
                    w=paharika_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in paharika and b in paharika:
                    start=paharika.index(a)
                    end=paharika.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in paharika_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='723' or t=='724' or t=='udayan' or t=='dyn':
        if c in ctg_syl:
            
            if a in final_destination and b in final_destination:
                if a in udayan and b in udayan:
                    s=ctg_syl.index(c)
                    w=udayan_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in udayan and b in udayan:
                    start=udayan.index(a)
                    end=udayan.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in udayan_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')  
            
            
            
    elif t=='729' or t=='730' or t=='meghna' or t=='mgn':
        if c in ctg_chand:
            
            if a in final_destination and b in final_destination:
                if a in meghna and b in meghna:
                    s=ctg_chand.index(c)
                    w=meghna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in meghna and b in meghna:
                    start=meghna.index(a)
                    end=meghna.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in meghna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
                      
            
    elif t=='735' or t=='736' or t=='augnibina' or t=='agnbn':
        if c in dhk_tara:
            
            if a in final_destination and b in final_destination:
                if a in augnibina and b in augnibina:
                    s=dhk_tara.index(c)
                    w=augnibina_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in augnibina and b in augnibina:
                    start=augnibina.index(a)
                    end=augnibina.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in augnibina_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='745' or t=='746' or t=='jamuna' or t=='jmn':
        if c in dhk_tara:
            
            if a in final_destination and b in final_destination:
                if a in jamuna and b in jamuna:
                    s=dhk_tara.index(c)
                    w=jamuna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in jamuna and b in jamuna:
                    start=jamuna.index(a)
                    end=jamuna.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in jamuna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')   
            
            
          
            
    elif t=='749' or t=='750' or t=='egarosindur_godhuli' or t=='grsndr_gdl':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in egarosindur_godhuli and b in egarosindur_godhuli:
                    s=dhk_kisore.index(c)
                    w=egarosindur_godhuli_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in egarosindur_godhuli and b in egarosindur_godhuli:
                    start=egarosindur_godhuli.index(a)
                    end=egarosindur_godhuli.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in egarosindur_godhuli_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
           
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
             
            
            
    elif t=='737' or t=='738' or t=='egarosindur_provati' or t=='grsndr_prvt':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in egarosindur_provati and b in egarosindur_provati:
                    s=dhk_kisore.index(c)
                    w=egarosindur_provati_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in egarosindur_provati and b in egarosindur_provati:
                    start=egarosindur_provati.index(a)
                    end=egarosindur_provati.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in egarosindur_provati_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='781' or t=='782' or t=='kishoreganj' or t=='ksrgnj':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in kishoreganj and b in kishoreganj:
                    s=dhk_kisore.index(c)
                    w=kishoreganj_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in kishoreganj and b in kishoreganj:
                    start=kishoreganj.index(a)
                    end=kishoreganj.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in kishoreganj_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')   
                        
            

    elif t=='751' or t=='752' or t=='lalmoni' or t=='llmn':
        if c in dhk_lal:
            
            if a in final_destination and b in final_destination:
                if a in lalmoni and b in lalmoni:
                    s=dhk_lal.index(c)
                    w=lalmoni_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in lalmoni and b in lalmoni:
                    start=lalmoni.index(a)
                    end=lalmoni.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in lalmoni_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
           
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
             
            
            
    elif t=='771' or t=='772' or t=='rangpur' or t=='rngpr':
        if c in dhk_rang:
            
            if a in final_destination and b in final_destination:
                if a in rangpur and b in rangpur:
                    s=dhk_rang.index(c)
                    w=rangpur_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in rangpur and b in rangpur:
                    start=rangpur.index(a)
                    end=rangpur.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in rangpur_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='797' or t=='798' or t=='kurigram' or t=='krgrm':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in kurigram and b in kurigram:
                    s=dhk_kisore.index(c)
                    w=kurigram_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in kurigram and b in kurigram:
                    start=kurigram.index(a)
                    end=kurigram.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in kurigram_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')             
            
          
            
            
    elif t=='797' or t=='799' and t=='mohonganj' or t=='mngnj':
        if c in dhk_mohon:
            
            if a in final_destination and b in final_destination:
                if a in mohonganj and b in mohonganj:
                    s=dhk_mohon.index(c)
                    w=mohonganj_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mohonganj and b in mohonganj:
                    start=mohonganj.index(a)
                    end=mohonganj.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mohonganj_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='777' or t=='778' or t=='haowr' or t=='wr':
        if c in dhk_mohon:
            
            if a in final_destination and b in final_destination:
                if a in haowr and b in haowr:
                    s=dhk_kisore.index(c)
                    w=dhk_mohon[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in haowr and b in haowr:
                    start=haowr.index(a)
                    end=haowr.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in haowr_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')             
            
'''            
              

            
    else:
        print('train name invalid')          
            
           
 

            
    elif t=='725' or t=='726' or t=='sundarban' or t=='sndrbn':
        if temp=='0':
            print('sundarban train goes to these places:')
            for t in sundarban:
                print(t)      
        elif temp in sundarban:
            if temp=='dhaka':
                print('Khulna')
            elif temp=='khulna':
                print('Dhaka')
            else:
                print('on Dhaka-khulna route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='727' or t=='728' or t=='rupsa' or t=='rps':
        if temp=='0':
            print('rupsa train goes to these places:')
            for t in rupsa:
                print(t)
        elif temp in rupsa:
            if temp=='chilahati':
                print('khulna')
            elif temp=='khulna':
                print('chilahati')
            else:
                print('on khulna-chilahati route')
        else:
            print('Sorry does not go there')
        

            
 
            
            
    elif t=='731' or t=='732' or t=='borendra' or t=='brndr':
        if temp=='0':
            print('borendra train goes to these places:')
            for t in borendra:
                print(t)
        elif temp in borendra:
            if temp=='chilahati':
                print('rajshahi')
            elif temp=='rajshahi':
                print('chilahati')
            else:
                print('on rajshahi-chilahati route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='733' or t=='734' or t=='titumir' or t=='ttmr':
        if temp=='0':
            print('titumir train goes to these places:')
            for t in titumir:
                print(t)      
        elif temp in titumir:
            if temp=='chilahati':
                print('rajshahi')
            elif temp=='rajshahi':
                print('chilahati')
            else:
                print('on rajshahi-chilahati route')
        else:
            print('Sorry does not go there')
                        
 

            
            
        
            
            
            
    elif t=='747' or t=='748' or t=='seemanta' or t=='smnt':
        if temp=='0':
            print('seemanta train goes to these places:')
            for t in seemanta:
                print(t)
        elif temp in seemanta:
            if temp=='dhaka':
                print('Chittagong')
            elif temp=='chittagong':
                print('Dhaka')
            else:
                print('on Dhaka-Chittagong route')
        else:
            print('Sorry does not go there')
        

            

        

            
    elif t=='753' or t=='754' or t=='silk_city' or t=='slk_cty':
        if temp=='0':
            print('silk_city train goes to these places:')
            for t in silk_city:
                print(t)    
        elif temp in silk_city:
            if temp=='dhaka':
                print('rajshahi')
            elif temp=='rajshahi':
                print('Dhaka')
            else:
                print('on Dhaka-Rajshahi route')
        else:
            print('Sorry does not go there')
                        

    elif t=='755' or t=='756' or t=='modhumati' or t=='mdmt':
        if temp=='0':
            print('modhumati train goes to these places:')
            for t in modhumati:
                print(t)
        elif temp in modhumati:
            if temp=='goalandaghat':
                print('rajshahi')
            elif temp=='rajshahi':
                print('goalandaghat')
            else:
                print('on Goalandaghat-Rajshahi route')
        else:
            print('Sorry does not go there')
        

 
            
            
            
    elif t=='759' or t=='760' or t=='padma' or t=='pdm':
        if temp=='0':
            print('padma train goes to these places:')
            for t in padma:
                print(t)
        elif temp in padma:
            if temp=='dhaka':
                print('rajshahi')
            elif temp=='rajshahi':
                print('Dhaka')
            else:
                print('on Dhaka-Rajshahi route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='761' or t=='762' or t=='shagordari' or t=='sgrdr':
        if temp=='0':
            print('shagordari train goes to these places:')
            for t in shagordari:
                print(t)     
        elif temp in shagordari:
            if temp=='khulna':
                print('rajshahi')
            elif temp=='rajshahi':
                print('khulna')
            else:
                print('on Khulna-Rajshahi route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='763' or t=='764' or t=='chitra' or t=='ctr':
        if temp=='0':
            print('chitra train goes to these places:')
            for t in chitra:
                print(t)
        elif temp in chitra:
            if temp=='dhaka':
                print('khulna')
            elif temp=='khulna':
                print('Dhaka')
            else:
                print('on Dhaka-Khulna route')
        else:
            print('Sorry does not go there')
        

            
    elif t=='765' or t=='766' or t=='nelsagore' or t=='nlsgr':
        if temp=='0':
            print('nelsagore train goes to these places:')
            for t in nelsagore:
                print(t)      
        elif temp in nelsagore:
            if temp=='dhaka':
                print('chilahati')
            elif temp=='chilahati':
                print('Dhaka')
            else:
                print('on Dhaka-Chilahati route')
        else:
            print('Sorry does not go there')      
            
            
            

        

            
    elif t=='769' or t=='770' or t=='dhumkatu' or t=='dmkt':
        if temp=='0':
            print('dhumkatu train goes to these places:')
            for t in dhumkatu:
                print(t)      
        elif temp in dhumkatu:
            if temp=='dhaka':
                print('rajshahi')
            elif temp=='rajshahi':
                print('Dhaka')
            else:
                print('on Dhaka-Rajshahi route')
        else:
            print('Sorry does not go there')
            
            

 
            
            
    elif t=='775' or t=='776' or t=='sirajganj' or t=='srjgnj':
        if temp=='0':
            print('sirajganj train goes to these places:')
            for t in sirajganj:
                print(t)
        elif temp in sirajganj:
            if temp=='dhaka':
                print('sirajganj')
            elif temp=='sirajganj':
                print('Dhaka')
            else:
                print('on Dhaka-Sirajganj route')
        else:
            print('Sorry does not go there')
        

  )


            
    elif t=='783' or t=='784' or t=='faridpur' or t=='frdpr':
        if temp=='0':
            print('faridpur train goes to these places:')
            for t in faridpur:
                print(t)      
        elif temp in faridpur:
            if temp=='rajbari':
                print('faridpur')
            elif temp=='faridpur':
                print('rajbari')
            else:
                print('on Rajbari-Faridpur route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='785' or t=='786' or t=='bijoy' or t=='bjy':
        if temp=='0':
            print('faridpur train goes to these places:')
            for t in faridpur:
                print(t)
        elif temp in faridpur:
            if temp=='mymensingh':
                print('Chittagong')
            elif temp=='chittagong':
                print('mymensingh')
            else:
                print('on Mymensingh-Chittagong route')
        else:
            print('Sorry does not go there')
        

            
    
            
            
            
    elif t=='789' or t=='790' or t=='mohonganj' or t=='mngnj':
        if temp=='0':
            print('mohonganj train goes to these places:')
            for t in mohonganj:
                print(t)
        elif temp in mohonganj:
            if temp=='dhaka':
                print('mohonganj')
            elif temp=='mohonganj':
                print('Dhaka')
            else:
                print('on Dhaka-Mohonganj route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='3107' or t=='3108' or t=='3109' or t=='3110' or t=='moitree' or t=='mtr':
        if temp=='0':
            print('moitree train goes to these places:')
            for t in moitree:
                print(t)      
        elif temp in moitree:
            if temp=='dhaka_cantt':
                print('kolkata')
            elif temp=='kolkata':
                print('dhaka_cantt')
            else:
                print('on dhaka_cantt-kolkata route')
        else:
            print('Sorry does not go there')
            
            
            
    elif t=='3129' or t=='3130' or t=='bandhan' or t=='bndn':
        if temp=='0':
            print('bandhan train goes to these places:')
            for t in bandhan:
                print(t)
        elif temp in bandhan:
            if temp=='khulna':
                print('kolkata')
            elif temp=='kolkata':
                print('khulna')
            else:
                print('on khulna-kolkata route')
        else:
            print('Sorry does not go there')
            
            
            
    else:
        print('Invalid')
        
'''

