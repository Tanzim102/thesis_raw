#OK -_-

subarna=['dhaka','chittagong']
sonar_bangla=['dhaka','chittagong']
mahanagar_provati=["dhaka","chittagong"]
mahanagar_godhuli=["dhaka","chittagong"]
mahanagar=["dhaka","chittagong"]
turna=["dhaka","chittagong"]


ekota=['dhaka','parbatipur','dinajpur']
drutajan=['dhaka','parbatipur','dinajpur']
panchagarh=['dhaka','parbatipur','dinajpur']


tista=['dhaka','mymensingh','jamalpur','jamalpur_town','dewanganj_bazar']
brahmaputro=['dhaka','mymensingh','jamalpur','jamalpur_town','dewanganj_bazar']


parabat=['dhaka','srimangal','kulaura','sylhet']
kalni=['dhaka','srimangal','kulaura','sylhet']
joyenteeka=['dhaka','srimangal','kulaura','sylhet']
upaban=['dhaka','srimangal','kulaura','sylhet']


upakul=['dhaka','noakhali']


lalmoni=['dhaka','bonar_para','kaunia','lalmonirhat']


rangpur=['dhaka','bbsetu_e','santaher','bogura','bonar_para','gaibandha','pirgacha','rangpur']
kurigram=['dhaka','parbatipur','rangpur']


haowr=['dhaka','mymensingh','mohonganj']


 
kopotakha=['khulna','chuadanga','ishurdi','rajshahi']
shagordari=['khulna','chuadanga','ishurdi','rajshahi']

chitra=['khulna','chuadanga','ishurdi','bbsetu_e','dhaka']
sundarban=['khulna','chuadanga','ishurdi','bbsetu_e','dhaka']


rupsa=['khulna','chuadanga','ishurdi','natore','santaher','joypurhat','phulbari','parbatipur','saidpur','chilahati']
seemanta=['khulna','chuadanga','ishurdi','natore','santaher','joypurhat','phulbari','parbatipur','saidpur','chilahati']


banalata=['rajshahi','dhaka']
silk_city=['rajshahi','ishurdi','ishurdi_bypass','chatmohar','ullapara','sm_m_monsur_ali','bbsetu_e','dhaka']
padma=['rajshahi','ishurdi','ishurdi_bypass','chatmohar','ullapara','sm_m_monsur_ali','bbsetu_e','dhaka']
dhumkatu=['rajshahi','ishurdi','ishurdi_bypass','chatmohar','ullapara','sm_m_monsur_ali','bbsetu_e','dhaka']



nelsagore=['dhaka','parbatipur','chilahati']


bandhan=['kolkata','khulna']
moitree=['kolkata','dhaka_cantt']


faridpur=['faridpur','rajbari']


def ACavailable(x,y):
            
    if x in banalata:
        if y in banalata:
            print('banalata')
            
    if x in bandhan:
        if y in bandhan:
            print('bandhan')
            

    if x in brahmaputro:
        if y in brahmaputro:
            print('brahmaputro')
            
    if x in chitra:
        if y in chitra:
            print('chitra')
            
    if x in dhumkatu:
        if y in dhumkatu:
            print('dhumkatu')
            
            
    if x in drutajan:
        if y in drutajan:
            print('drutajan')
            
    if x in ekota:
        if y in ekota:
           print('ekota')
            
    if x in faridpur:
        if y in faridpur:
            print('faridpur')
            
    if x in haowr:
        if y in haowr:
            print('haowr')

    if x in joyenteeka:
        if y in joyenteeka:
            print('joyenteeka')
            
    if x in kalni:
        if y in kalni:
            print('kalni')
       
    if x in kopotakha:
        if y in kopotakha:
            print('kopotakha')
            
    if x in kurigram:
        if y in kurigram:
            print('kurigram')
            
    if x in lalmoni:
        if y in lalmoni:
            print('lalmoni')
       
    if x in mahanagar:
        if y in mahanagar:
            print('mahanagar')
            
    if x in mahanagar_godhuli:
        if y in mahanagar_godhuli:
            print('mahanagar_godhuli')
            
    if x in mahanagar_provati:
        if y in mahanagar_provati:
            print('mahanagar_provati')

            
    if x in moitree:
        if y in moitree:
            print('moitree')
            
            
    if x in padma:
        if y in padma:
            print('padma')
            
    if x in parabat:
        if y in parabat:
            print('parabat')
            
    if x in nelsagore:
        if y in nelsagore:
            print('nelsagore')
            
    if x in rangpur:
        if y in rangpur:
            print('rangpur')
            
    if x in rupsa:
        if y in rupsa:
            print('rupsa')
            
    if x in seemanta:
        if y in seemanta:
            print('seemanta')

    if x in shagordari:
        if y in shagordari:
            print('shagordari')
            
    if x in silk_city:
        if y in silk_city:
            print('silk_city')
             
            
    if x in sonar_bangla:
        if y in sonar_bangla:
            print('sonar_bangla')

    if x in subarna:
        if y in subarna:
            print('subarna')
            
    if x in sundarban:
        if y in sundarban:
            print('sundarban')

    if x in tista:
        if y in tista:
            print('tista')
            
             
    if x in turna:
        if y in turna:
            print('turna')
            
    if x in upaban:
        if y in upaban:
            print('upaban')
            
    if x in upakul:
        if y in upakul:
            print('upakul')
            
    else:
        print('sorry no ac service available')

