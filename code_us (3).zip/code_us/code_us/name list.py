place_names=['abdulpur','accalpur','agimnagar','ahasangang','akhaura','alamdanga','amirgang','aowlia_nagar','arani','arikhola','ashuganj','azampur',
             'b_siajur_islam','badarganj','bajitpur','bamondanga','banani','bangabandhu_htp','barhatta','bbsetu_e','bbsetu_w','benapole','bhairab_bazar','bhairamara','bhanuganj','biman_bandar','birampur','birole','bogura','bojra','bonarpara','boral_bridge','brahmanbaria',
             'chapainababganj','chapta','chatmohar','chilahati','chittagong','choumuhani','chuadanga','cirir_bandar','comilla','court_chandpur',
             'darsana','darsana_halt','daulatpur','Da_cantonment','dewanganj_bazar','dhoala','dinajpur','domar','durmut',
             'fatema_namar','feni',
             'gachihata','gafargaon','gaibandha','gobra','gouripur_myn','gunaboti',
             'hasanpur','horoshpur',
             'ibrahimabad','imam_bari','ishurdi','ishurdi_dhaka','ishurdi_bypass','islampur_bazar',
             'jamalpur','jamtail','jaydebpur','jessore','jhikargacha','joypurhat',
             'kaunia','kawrait','khanabari','khulna','kishoreganj','kismat','krishi_univarsity','kulaura','kuliarchar','kurigram',
             'lahirimohanpur','laksam','lalmonirhat',
             'madhnagar','maijdi_court','maizgaon','manik_khali','melandah_bazar','methikanda','mirpur','mirzapur','mobarakgong','mohera','mohonganj','montala','moshakhali','mouchak','mukundupur','muladuli','mymensingh'
             'nandina','nangalkot','narsingdi','nathar_patua','natore','nayapara','neelfamari','netrokona','noakhali','noapara','nurundi',
             'paghachong','panchabibi','panchagarh','parbatipur','phulbari','pirgacha','pirganj','poradaha','pyerpur',
             'qosba',
             'rajapur','pajendrapur','pajshahi','rangpur','ruhiya',
             'sadanandapur','saidpur','santaher','sararchar','sarishabari','satabgonj','satkhamaer','sh_m_monsur_ali','shahagi_bazar','shaistagonj','shamshernagar','shemganj','shordha_road','shoshidol','sirajganj','sirajganj_bazar','sonaimuri','sonatola','srimangal','sripur','syadabad','sylhet',
             'tangail','tangi','tarakandi','tejgon','thakurakona','thakurgaon','thakurgaon_road','ullapara']



subarna=['dhaka','biman_bandar','chittagong']
sonar_bangla=['dhaka','biman_bandar','chittagong']
mahanagar_provati=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar_godhuli=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar=["dhaka","biman_bandar","narsingdi","bhairab_bazar","ashuganj","brahmanbaria","akhaura","qosba","comilla","laksam","nangalkot","feni","chittagong"]
turna=["dhaka","biman_bandar","bhairab_bazar","ashuganj","brahmanbaria","akhaura","comilla","laksam","feni","chittagong"]


ekota=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','ishurdi_bypass','natore','santahar','accalpur',
       'joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']
drutajan=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','jamtail','chatmohar','natore','santahar','accalpur',
       'joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']


tista=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','pyerpur','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']
brahmaputro=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','pyerpur','nandina','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']


parabat=[]
kalni=['dhaka','biman_bandar','bhairab_bazar','brahmanbaria','azampur','shaistagonj','srimangal','shamshernagar','kulaura','maizgaon','sylhet']



 

 
