from where does train turna come to chittagong
Per day how many trains are available from dhaka to chittagong
what are the names of train travel from dhaka to chittagong
what is the number of train ekota
what is the seat cost of train from dhaka to feni in turna in s_chair
what is the seat cost of train from domar to dhaka in nelsagore in s_chair
what is the train name of train numbered 707



available a ADD:
    turna ki sombare avaiable frm ctg to dhk
    ###


question
    1:
        from where does train turna come to chittagong
        where does subarna go from dhaka
        where does 701 go from chittagong
        where does 769 go from rajshahi
        where does drutojan go from joypurhat
        where does mohanagar go from chittagong
        where does mohanagor go
        from where does subarna come //jaigar list
        STOPAGE?

    
    2:
        Per day how many trains are available from dhaka to chittagong?
        what are the names of train travel from dhaka to chittagong
        how many train travel from dhaka to dinajpur
        what are the numbers of train travel from tarakandi to dhaka 
        what are the numbers of train travel from khulna to jessore 
        what are the names of train travel from dhaka to chittagong
        how many junction route from dhaka to khulna
        How many train for from Dhaka to Khulna route?
        Per day how many trains are available from dhaka to chittagong?
        give me the names of train travel to khulna from dhaka
 
    
    3:
        what is the number of train ekota
        what is the number of train mahanagar_godhuli
        what is the train number of train named ekota
        
    
    4:
        what is the name of train 707
        what is the train name of train numbered 707
    
    5&6:
        on which day train named bijoy does not go to gouripur_myn from bhatiary
        which is the day that train ekota does not go
        which is the offday of trains from dhaka to dinajpur
        on which day train does not go from chittagong to dhaka
        on which day train named beejay does not go to gouripur_myn from bhatiary
        on which day 3129 does not go
        which is the day for train numbered 787 does not go to dhaka
        on which day train ekota does not go from dinajpur to dhaka
        What is the offday for train named lalmoni from bogura to dhaka
    
    7:
        give me the list of trains of dhaka //train er list
        give me the list of trains of those stop in bogura
        what are the trains for sylhet
        what are the name list of trains stop in bogura
        
    12:
       dhk to khu train khokhn jai/rouna dei  //kon train?
       " subarna //time bolbe --> if jai= ashe=
        What are the time of the trains leaving khulna towards dhaka?
        what is the time for sundarban go from dh to kh 
        When does Sundarban Express leave for Dhaka from Khulna?
        when does the train subarna go from dhaka to khulna
        What approximate time the train chitra will take to reach Khulna from dhaka?
        Give me the time of starting of Rupsha?
        What is the schedule from dhaka to khulna?
        When train Tista will arrive?
        


        
    8:
        what is the seat cost of in sundarban
        what is the seat cost of train from dhaka to khulna
        what is the seat cost of train from dhaka to dinajpur in s_chair in panchagar
        what is the seat cost of train from dhaka to feni in turna in s_chair
        what is the seat cost of train to khulna from dhaka in sundarban in s_chair
        what is the seat cost of train from chittagong to biman_bandar in subarna in snigdha 
           
        How much is the fare for ac_s tickets in Sundarban express train from bogura to domar?
        
        what is the seat cost of train from biman_bandar to parbatipur in s_chair in ekota
        
        what is the seat cost of train from dhaka to feni in turna in s_chair
        what is the seat cost of train to feni from dhaka in turna in s_chair
        what is the seat cost of train from feni to dhaka in turna in s_chair
        what is the seat cost of train from maizgaon to feni in paharika in s_chair
        what is the seat cost of train from maizgaon to feni in paharika in s_chair
     
    10:
        is there ac in train from dhaka to khulna
    
    
    11:
        is there any train available from khulna to domar
        Is train available at night from dhaka to khulna
        Is Chitra express train from dhaka to khulna available on Mondays?
        

    9:
        what is the next station of gafargaon for subarna
        what is the previous station of gafargaon
        what is the next station for subarna of chilahati
        what is the previous station of khulna for rupsa
        
     13:

         How many hours it takes traveling from khulna to Chilahati using Chattrala Express?
         How long does it take for Sonar Bangla train to reach Chittagong from Dhaka?

     *: does train ekota go at monday   
    random:
        When the Bangladesh Railways introduced in Bangladesh
        Which services does BR provide
        Who is the present rail minister in Bangladesh
        largest station in bangladesh
        does give food in train
        does train service costly
        need printed copy of online ticket