# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 04:16:12 2019

@author: CITY
"""
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 15 21:18:10 2019

@author: CITY
"""

from nltk.tokenize import sent_tokenize, word_tokenize
from collections import Counter 
# Import WordNetLemmatizer
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
import nltk
import re

from fixed_answer import *
from WhereGoesOrComes import * #1
from RouteHowMany import * #2
from RouteTrainNameNo import * #2
from OnlyNumber import * #3
from OnlyName import * #4
from Offday import * #5&6
from listOfTrainsforAnyPlace import * #7
from train_time import * #8
from seatFair import * #9
from ACavailable import * #10
from trainAvailable import * #11
from nextStation import * #12
from how_long_it_takes import * #13


ENGLISH_STOPS = set(stopwords.words('english'))

lenPattern=[8,7]
whQues=["who","what","where","how","why","when","which"]
pre=["to","from"] 
yes_no=["is","can","are","does","there"]
extra=["approximate","approriate","there","express","station"]
cut=["why","buy","book","bought","coordinate","ticket"]

tokennns=[]
nouns=[]
place_add=[]
vowels=["a","e","i","o","u"]
train_name=['ekota', 
            'upakul']

news=['kt',
      'pkl']

place_names=['abdulpur','accalpur','agimnagar','ahasangang','akhaura','alamdanga','amirgang','aowlia_nagar','arani','arikhola','ashuganj','azampur',
             'b_siajur_islam','badarganj','bajitpur','bamondanga','banani','bangabandhu_htp','barhatta','bbsetu_e','bbsetu_w','benapole','bhairab_bazar','bhairamara','bhanuganj','bhatiary','biman_bandar','birampur','birole','bogura','bojra','bonarpara','boral_bridge','bramanbaria',
             'chapainababganj','chapta','chatmohar','chilahati','chittagong','choumuhani','chuadanga','cirir_bandar','comilla','court_chandpur',
             'darsana','darsana_halt','daulatpur','da_cantonment','dewanganj_bazar','dhaka','dhoala','dinajpur','domar','durmut',
             'fatema_namar','feni',
             'gachihata','gafargaon','gaibandha','gobra','gouripur_myn','gunaboti',
             'hasanpur','horoshpur',
             'ibrahimabad','imam_bari','ishurdi','ishurdi_dhaka','ishurdi_bypass','islampur_bazar',
             'jamalpur','jamtail','jaydebpur','jessore','jhikargacha','joypurhat',
             'kaunia','kawrait','khanabari','khulna','kishoreganj','kismat','krishi_univarsity','kulaura','kuliarchar','kurigram',
             'lahirimohanpur','laksam','lalmonirhat',
             'madhnagar','maijdi_court','maizgaon','manik_khali','melandah_bazar','methikanda','mirpur','mirzapur','mobarakgong','mohera','mohonganj','montala','moshakhali','mouchak','mukundupur','muladuli','mymensingh'
             'nandina','nangalkot','narsingdi','nathar_patua','natore','nayapara','neelfamari','netrokona','noakhali','noapara','nurundi',
             'paghachong','panchabibi','panchagarh','parbatipur','phulbari','pirgacha','pirganj','poradaha','pyerpur',
             'qosba',
             'rajapur','pajendrapur','pajshahi','rangpur','ruhiya',
             'sadanandapur','saidpur','santaher','sararchar','sarishabari','satabgonj','satkhamaer','sh_m_monsur_ali','shahagi_bazar','shaistagonj','shamshernagar','shemganj','shordha_road','shoshidol','sirajganj','sirajganj_bazar','sonaimuri','sonatola','srimangal','sripur','syadabad','sylhet',
             'tangail','tangi','tarakandi','tejgon','thakurakona','thakurgaon','thakurgaon_road','ullapara']


            
          
            
def WhereGoesOrComes(): #1...........
    place=0
    flag=0
    for word,pos in nltk.pos_tag(tokennns):
        nouns.append(word)
        
    aa=len(nouns)
    print(aa)
    
        
    for tt in nouns:
        for t in place_names:
            if t==tt:
                place=1
                place_add.append(t)
                
   
    for tt in nouns:
        for t in train_name:
            if t==tt:
                flag=1
                print(t)
                
    if flag==0:
        
        for t in range(aa):
            for tt in nouns[t]:
                if tt in vowels:
                    nouns[t]=nouns[t].replace(tt,"")
                    
        for tt in news:
            for t in nouns:
                if tt==t:
                    print(tt)
                    
                
            
      
            
        print('please mention train name correctly')
        
            
            
        
   
                            
    
def answer(patternNo,tokenn):
    for t in tokenn:
        if t not in ENGLISH_STOPS:
            tokennns.append(t);
            
    if patternNo==1:
        WhereGoesOrComes()
        

        
        
        
    
    
def precision_count(strr,l):
    for i in 2:
        t=0
        for j in lenPattern[i]:
            for k in l:
                if re.search(patCol[i][j],strr[k]):
                    t=t+1
                     
        t=t/lenPattern[i]
        pre.append(t)
    maxx=-100
    num=0
    for i in 2:
        if pre[i]>maxx:
            maxx=pre[i]
            num=i
    print(num+1," precision:",maxx)
    return num
p=[]

#1 
p.append(r"(from where |where |give )(does )?(train )?(no |named )?([a-z]*|\d{3,4})( start | come | depart | come | leave | go | travel | pass )(from )?(to |towards )?([a-z]*)")


#what is the seat cost of train from jessore to dhaka in Subarna in s_chair

inp=input("Enter Question:")
sent= sent_tokenize(inp)
print(sent)
for i in sent:
    words = word_tokenize(i)
print(words)
lower_tokens = [t.lower() for t in words]

# Retain alphabetic words: alpha_only
#alpha_only = [t for t in lower_tokens if t.isalpha()]

no_stops= []

# Remove all stop words: no_stops
for t in lower_tokens:
    if t in whQues or t in pre or t not in ENGLISH_STOPS:
        if t not in extra:
            no_stops.append(t)

# Instantiate the WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()

# Lemmatize all tokens into a new list: lemmatized
lemmatized = [wordnet_lemmatizer.lemmatize(t) for t in no_stops]
print(lemmatized)
# Create the bag-of-words: bow
bow = Counter(lemmatized)

# Print the 10 most common tokens 
print(bow.most_common(10))

string=""
string1=""
for t in lemmatized:
    string=string+t+" "
    string1=string1+"("+t+" " ")"
#print('String is:' + string)
print('Pattern is:' + string1)


cnt=0 
m=0


pattern_flag=0
leave=0

if "why" in string or "buy" in string or "book" in string or "give ticket" in string:
    print(t)
    leave=1
    
if leave==1:
    print('...sorry, NOT ANSWERED...')    
  
else:
    for t in p:
        cnt=cnt+1
        if re.search(t,string):
            print("yes matched precision 1")
            print("Pattern ",cnt)
            print(t)
            m=1
            answer(cnt,lemmatized)
            pattern_flag=1
            break

    if pattern_flag==0:
        fixed_answer(inp)


'''

vowels=['a','e','i','o','u']
lists=['bogura','upokal']
listss=['bgr','pkl']
a=0
nouns=[]
x=input('Q:')
print(x)
for word,pos in nltk.pos_tag(x):
    nouns.append(word)
    print(nouns)
for t in lists:
    for tt in nouns:
        if t==tt:
            a=1
            print(t)
        
'''