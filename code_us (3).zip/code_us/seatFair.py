#OK

final_destination=['dhaka', 'chittagong', 'santaher', 'rajshahi', 'khulna', 'koltaka', 'faridpur', 'rajbari', 'dinajpur',
                   'dewanganj_bazar', 'chandpur', 'tarakandi', 'sylhet', 'noakhali', 'burimari','kishoreganj', 'rangpur',
                   'mohonganj', 'lalmonirhat', 'mymensingh', 'chilahati', 'goalandaghat', 'sirajganj']


dhk_ctg=['ac_s','ac_b','f_seat','f_berth','snigdha','s_chair']
subarna=['dhaka','biman_bandar','chittagong']
subarna_cost=['0','0','0','0','725','380']
subarna_raw_cost=['0','380']
sonar_bangla=['dhaka','biman_bandar','chittagong']
sonar_bangla_cost=['1100','0','800','0','1000','600']
sonar_bangla_raw_cost=['0','600']
mahanagar_provati=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar_provati_cost=['788','0','460','0','656','345']
mahanagar_provati_raw_cost=["0","75","40","15","45","20","25","15","110"]
mahanagar_godhuli=["dhaka","biman_bandar","bhairab_bazar","brahmanbaria","akhaura","comilla","laksam","gunaboti","feni","chittagong"]
mahanagar_godhuli_cost=['788','0','460','0','656','345']
mahanagar_godhuli_raw_cost=["0","75","40","15","45","20","25","15","110"]
mahanagar=["dhaka","biman_bandar","narsingdi","bhairab_bazar","ashuganj","brahmanbaria","akhaura","qosba","comilla","laksam","nangalkot","feni","chittagong"]
mahanagar_cost=['0','1229','0','0','656','345']
mahanagar_raw_cost=["0","75","40","15","45","20","25","15","110"]
turna=["dhaka","biman_bandar","bhairab_bazar","ashuganj","brahmanbaria","akhaura","comilla","laksam","feni","chittagong"]
turna_cost=['0','1229','0','735','656','345']
turna_raw_cost=["0","75","40","0","15","45","20","40","110"]


dhk_dinaj=['ac_s','ac_b','snigdha','s_chair']
ekota=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','ishurdi_bypass','natore','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']
ekota_cost=['0','1649','892','465']
ekota_raw_cost=['0','50','65','20','90','65','30','40','15','15','5','20','10','15','25','0']
drutajan=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','jamtail','chatmohar','natore','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','cirir_bandar','dinajpur']
drutajan_cost=['1070','0','892','465']
drutajan_raw_cost=['0','50','65','20','90','65','30','40','15','15','5','20','10','15','25','0']
panchagarh=['dhaka','biman_bandar','parbatipur','dinajpur']
panchagarh_cost=['1070','0','892','465']
panchagarh_raw_cost=['0','440','25']


san_dinaj=['s_chair']
doloncapa=['santaher','talora','bogura','sonatola','mohimaganj','bonar_para','gaibandha','bamondanga','kaunia','rangpur','badar_ganj','kholahati','parbatipur','cirir_bandar','dinajpur']
doloncapa_cost=['255']
doloncapa_raw_cost=['50','5','30','5','10','20','25','45','0','20','20','0','15','10']


dhk_dewan=['ac_s','f_seat','shovan','snigdha','s_chair']
tista=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','pyerpur','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']
tista_cost=['512','300','0','426','225']
tista_raw_cost=['0','50','55','35','25','25','0','15','20','30']
brahmaputro=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','jamalpur','jamalpur_town','melandah_bazar','islampur_bazar','dewanganj_bazar']
brahmaputro_cost=['0','300','185','0','225']
brahmaputro_raw_cost=['0','50','55','35','50','0','15','20','30']


dhk_syl=['ac_s','ac_b','f_seat','f_berth','snigdha','s_chair','f_chair','shovan']
parabat=['dhaka','biman_bandar','bhairab_bazar','brahmanbaria','azampur','nayapara','shaistagonj','srimangal','bhanugach','kulaura','maizgaon','sylhet']
parabat_cost=['736','0','425','0','610','320','0','0']
parabat_raw_cost=['0','105','40','20','30','20','25','10','30','40','0']
kalni=['dhaka','biman_bandar','bhairab_bazar','azampur','shaistagonj','srimangal','shamshernagar','kulaura','sylhet']
kalni_cost=['0','0','0','0','0','320','425','265']
kalni_raw_cost=['0','105','60','50','25','25','15','40']
joyenteeka=['dhaka','biman_bandar','ashuganj','azampur','mukundupur','horoshpur','montala','nayapara','shahagi_bazar','shaistagonj','srimangal','bhanugach','kulaura','maizgaon','sylhet']
joyenteeka_cost=['736','0','425','0','0','320','425','265']
joyenteeka_raw_cost=['0','130','35','5','10','5','10','10','10','25','10','30','40','0']
upaban=['dhaka','biman_bandar','bhairab_bazar','azampur','shaistagonj','srimangal','shamshernagar','kulaura','maizgaon','sylhet']
upaban_cost=['0','1149','0','690','0','320','425','265']
upaban_raw_cost=['0','105','60','50','25','25','15','40','0']

dhk_noa=['ac_s','f_seat','shovan','s_chair']
upakul=['dhaka','biman_bandar','bhairab_bazar','qosba','nathar_patua','sonaimuri','bojra','choumuhani','maijdi_court','noakhali']
upakul_cost=['627','365','230','275']
upakul_raw_cost=['0','115','60','75','15','0','0','0','0']

san_buri=['shovan']
korotaya=['santaher','bogura','sonatola','bonar_para','gaibandha','bamondanga','pirgacha','kaunia','lalmonirhat','aditmari','tushvandar','hatibandha','patgram','burimari']
korotaya_cost=['220']

ctg_syl=['f_seat','f_berth','snigdha','s_chair','shovan']
paharika=['chittagong','feni','laksam','comilla','shaistagonj','srimangal','shamshernagar','kulaura','maizgaon','sylhet']
paharika_cost=['500','0','719','375','315']
paharika_raw_cost=['110','40','20','100','30','15','20','40','0']
udayan=['chittagong','feni','laksam','comilla','shaistagonj','srimangal','shamshernagar','kulaura','sylhet']
udayan_cost=['0','795','719','375','315']
udayan_raw_cost=['110','40','20','100','30','15','20','40']

ctg_chand=['f_chair','f_seat','shovan','s_chair']
meghna=['chittagong','meher','hajiganj','modhu_road','chandpur_court','chandpur']
meghna_cost=['260','260','165','195']
meghna_raw_cost=['170','25','0','0','0']

dhk_tara=['f_seat','shovan','s_chair']
augnibina=['dhaka','biman_bandar','gafargaon','mymensingh','jamalpur','jamalpur_town','sarisha_bari','tarakandi']
augnibina_cost=['300','190','225']
augnibina_raw_cost=['0','105','35','50','0','35','0']
jamuna=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','jamalpur','jamalpur_town','sarisha_bari','tarakandi']
jamuna_cost=['300','190','225']
jamuna_raw_cost=['0','50','55','35','50','0','35','0']


dhk_kisore=['f_chair','f_seat','shovan','s_chair','snigdha']
egarosindur_provati=['dhaka','biman_bandar','bhairab_bazar','bajipur','sararchar','kishoreganj']
egarosindur_provati_cost=['200','200','125','150','0']
egarosindur_provati_raw_cost=['0','105','20','5','20']
kishoreganj=['dhaka','biman_bandar','methikanda','bhairab_bazar','bajipur','sararchar','kishoreganj']
kishoreganj_cost=['200','200','125','150','288']
kishoreganj_raw_cost=['0','75','40','20','5','20']
egarosindur_godhuli=['dhaka','biman_bandar','methikanda','bhairab_bazar','bajipur','sararchar','kishoreganj']
egarosindur_godhuli_cost=['200','200','125','150','0']
egarosindur_godhuli_raw_cost=['0','75','40','20','5','20']


dhk_lal=['ac_b','s_chair','snigdha']
lalmoni=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','ullapara','boral_bridge','agimnagar','natore','santaher','bogura','sonatola','bonar_para','gaibandha','bamondanga','kaunia','lalmonirhat']
lalmoni_cost=['1781','966','505']
lalmoni_raw_cost=['0','50','65','20','90','20','20','35','20','40','35','25','10','15','20','40','0']


dhk_rang=['ac_s','ac_b','s_chair','snigdha']
rangpur=['dhaka','biman_bandar','bbsetu_e','chatmohar','natore','santaher','bogura','bonar_para','gaibandha','bamondanga','pirgacha','kaunia','kurigram','rangpur']
rangpur_cost=['1162','0','505','966']
rangpur_raw_cost=['0','135','135','50','40','35','35','15','20','15','10','10','5']
kurigram=['dhaka','biman_bandar','madhnagar','santaher','joypurhat','parbatipur','badar_ganj','rangpur']
kurigram_cost=['0','1672','470','903']
kurigram_raw_cost=['0','335','25','30','50','15','50']

dhk_mohon=['ac_b','f_berth','f_seat','shovan','snigdha','s_chair']
mohonganj=['dhaka','biman_bandar','gafargaon','mymensingh','gouripur_myn','shemganj','netrokona','thakurakona','barhatta','mohonganj']
mohonganj_cost=['0','0','295','185','426','220']
mohonganj_raw_cost=['0','105','35','25','15','15','0','25','0']
haowr=['dhaka','biman_bandar','jaydebpur','gafargaon','mymensingh','gouripur_myn','shemganj','netrokona','thakurakona','barhatta','mohonganj']
haowr_cost=['809','490','0','185','0','220']
haowr_raw_cost=['0','50','55','35','25','15','15','0','25','0']


ctg_my=['f_chair','f_seat','shovan','s_chair']
bijoy=['chittagong','bhatiary','feni','laksam','comilla','akhaura','bhairab_bazar','kishoreganj','gouripur_myn','mymensingh']
bijoy_cost=['515','515','320','385']
bijoy_raw_cost=['45','65','40','20','145','0','0','70','0']


khul_raj=['ac_s','snigdha','s_chair'] 
kopotakha=['khulna','noapara','jessore','mobarakgong','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','pakshi','ishurdi','agimnagar','rajshahi']
kopotakha_cost=['0','593','310']
kopotakha_raw_cost=['50','20','35','15','20','15','15','15','20','45','5','15','40']
shagordari=['khulna','noapara','jessore','mobarakgong','court_chandpur','safdarpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','pakshi','ishurdi','agimnagar','rajshahi']
shagordari_cost=['708','593','310']
shagordari_raw_cost=['50','20','35','15','10','10','15','15','15','20','45','5','15','40']


khul_dhk=['ac_b','ac_s','snigdha','s_chair']
chitra=['khulna','noapara','jessore','mobarakgong','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','ishurdi','chatmohar','boral_bridge','ullapara','sm_m_monsur_ali','bbsetu_e','tangail','mirzapur','jaydebpur','biman_bandar','dhaka']
chitra_cost=['0','1156','966','505']
chitra_raw_cost=['50','20','35','15','20','15','15','15','20','50','25','10','20','15','80','20','20','30','30','0']
sundarban=['khulna','noapara','jessore','mobarakgong','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','ishurdi','chatmohar','boral_bridge','ullapara','jamtail','sm_m_monsur_ali','bbsetu_e','tangail','mirzapur','jaydebpur','biman_bandar','dhaka']
sundarban_cost=['1781','0','966','505']
sundarban_raw_cost=['50','20','35','15','20','15','15','15','20','50','25','10','20','5','10','80','20','20','30','30','0']


khul_chila=['ac_b','ac_s','snigdha','s_chair']
rupsa=['khulna','noapara','jessore','court_chandpur','darsana_halt','chuadanga','alamdanga','poradaha','bhairamara','pakshi','ishurdi','natore','ahasangang','santaher','accalpur','joypurhat','birampur','phulbari','parbatipur','saidpur','neelfamari','chilahati']
rupsa_cost=['0','1070','892','465']
rupsa_raw_cost=['50','20','50','20','15','15','15','20','45','5','35','20','15','20','10','30','10','10','15','20','25']
seemanta=['khulna','noapara','jessore','darsana_halt','chuadanga','poradaha','bhairamara','ishurdi','natore','santaher','accalpur','joypurhat','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']
seemanta_cost=['1649','0','892','465']
seemanta_raw_cost=['50','20','70','15','30','20','50','35','35','20','10','30','10','10','15','20','20','5']


raj_chila=['f_seat','shovan','s_chair']
borendra=['rajshahi','abdulpur','natore','ahasangang','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']
borendra_cost=['365','230','275']
borendra_raw_cost=['50','10','25','20','15','10','5','20','10','15','10','15','25','45']
titumir=['rajshahi','abdulpur','natore','ahasangang','santaher','accalpur','joypurhat','panchabibi','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']
titumir_cost=['365','230','275']
titumir_raw_cost=['50','10','25','20','15','10','5','20','10','15','10','15','25','45']


raj_dhk=['ac_b','ac_s','snigdha','s_chair']
banalata=['rajshahi','dhaka']
banalata_cost=['0','0','725','375']
banalata_raw_cost=['375']
silk_city=['rajshahi','abdulpur','ishurdi_bypass','ishurdi','chatmohar','boral_bridge','ullapara','jamtail','sm_m_monsur_ali','bbsetu_e','tangail','mirzapur','jaydebpur','biman_bandar','dhaka']
silk_city_cost=['0','782','656','340']
silk_city_raw_cost=['50','20','5','20','15','20','10','10','85','20','25','30','30','0']
padma=['rajshahi','shordha_road','abdulpur','ishurdi_bypass','ishurdi','chatmohar','boral_bridge','ullapara','sm_m_monsur_ali','bbsetu_e','tangail','jaydebpur','biman_bandar','dhaka']
padma_cost=['0','782','656','340']
padma_raw_cost=['50','0','20','5','20','15','20','20','85','20','55','30','0']
dhumkatu=['rajshahi','abdulpur','arani','chatmohar','boral_bridge','sm_m_monsur_ali','bbsetu_e','jaydebpur','biman_bandar','dhaka']
dhumkatu_cost=['1223','0','656','340']
dhumkatu_raw_cost=['50','0','45','15','40','85','75','30','0']


rajba_goa=['f_seat','shovan']
modhumati=['rajshahi','ishurdi','pakshi','bhairamara','mirpur','poradaha','kustia','kustia_court','kumarkhali','khoksa','pangsha','kalukhali','rajbari','goalandaghat']
modhumati_cost=['322','202']


dhk_chila=['ac_s','snigdha','s_chair']
nelsagore=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','muladuli','natore','ahasangang','santaher','accalpur','joypurhat','birampur','phulbari','parbatipur','saidpur','neelfamari','domar','chilahati']
nelsagore_cost=['1133','949','495']
nelsagore_raw_cost=['0','50','65','20','150','35','20','20','15','15','25','10','15','15','15','25','0']


dhk_siraj=['snigdha','s_chair']
sirajganj=['dhaka','biman_bandar','jaydebpur','tangail','bbsetu_e','sm_m_monsur_ali','jamtail','sirajganj_bazar','sirajganj']
sirajganj_cost=['460','240']
sirajganj_raw_cost=['0','50','65','20','90','5','10','0']


def seatFair(a,b,c,t):
    cost=0
    count=-1
    
        
    if t=='701' or t=='702' or t=='subarna' or t=='sbrn':
        if c in dhk_ctg:
            if a in final_destination and b in final_destination:
                if a in subarna and b in subarna:
                    s=dhk_ctg.index(c)
                    w=subarna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in subarna and b in subarna:
                    start=subarna.index(a)
                    end=subarna.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in subarna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 

                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
    elif t=='787' or t=='788' or t=='sonar_bangla' or t=='snr_bngl':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in sonar_bangla and b in sonar_bangla:
                    s=dhk_ctg.index(c)
                    w=sonar_bangla_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in sonar_bangla and b in sonar_bangla:
                    start=sonar_bangla.index(a)
                    end=sonar_bangla.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in sonar_bangla_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)

                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
        else:
            print('this type of class service is not available for this train')
                    
                    
        
    elif t=='704' or t=='mahanagar_provati' or t=='mngr_prvt':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in mahanagar_provati and b in mahanagar_provati:
                    s=dhk_ctg.index(c)
                    w=mahanagar_provati_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mahanagar_provati and b in mahanagar_provati:
                    start=mahanagar_provati.index(a)
                    end=mahanagar_provati.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mahanagar_provati_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
    elif t=='703' or t=='mahanagar_godhuli' or t=='mngr_gdl':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in mahanagar_godhuli and b in mahanagar_godhuli:
                    s=dhk_ctg.index(c)
                    w=mahanagar_godhuli_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mahanagar_godhuli and b in mahanagar_godhuli:
                    start=mahanagar_godhuli.index(a)
                    end=mahanagar_godhuli.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mahanagar_godhuli_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
                    
        else:
            print('this type of class service is not available for this train')
                    
                    
                 
    elif t=='741' or t=='742' or t=='turna' or t=='trn':
        if c in dhk_ctg:
                
            if a in final_destination and b in final_destination:
                if a in turna and b in turna:
                    s=dhk_ctg.index(c)
                    w=turna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in turna and b in turna:
                    start=turna.index(a)
                    end=turna.index(b)
    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in turna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
                    
        else:
            print('this type of class service is not available for this train')
                    
                        

    elif t=='721' or t=='722' or t=='mahanagar' or t=='mngr':
        if c in dhk_ctg:
            
            if a in final_destination and b in final_destination:
                if a in mahanagar and b in mahanagar:
                    s=dhk_ctg.index(c)
                    w=mahanagar_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mahanagar and b in mahanagar:
                    start=mahanagar.index(a)
                    end=mahanagar.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mahanagar_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
                    
        else:
            print('this type of class service is not available for this train')
                    
                    
                    
                    
        
    elif t=='705' or t=='706' or t=='ekota' or t=='kt':
        if c in dhk_dinaj:
            
            if a in final_destination and b in final_destination:
                if a in ekota and b in ekota:
                    s=dhk_dinaj.index(c)
                    w=ekota_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in ekota and b in ekota:
                    start=ekota.index(a)
                    end=ekota.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in ekota_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                        
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')
            
            
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='757' or t=='758' or t=='drutajan' or t=='drtjn':
        if c in dhk_dinaj:

            if a in final_destination and b in final_destination:
                if a in drutajan and b in drutajan:
                    s=dhk_dinaj.index(c)
                    w=drutajan_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in drutajan and b in drutajan:
                    start=drutajan.index(a)
                    end=drutajan.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in drutajan_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')            
            
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='793' or t=='794' or t=='panchagarh' or t=='pncgr':
        if c in dhk_dinaj:
            
            if a in final_destination and b in final_destination:
                if a in panchagarh and b in panchagarh:
                    s=dhk_dinaj.index(c)
                    w=panchagarh_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in panchagarh and b in panchagarh:
                    start=panchagarh.index(a)
                    end=panchagarh.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in panchagarh_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')            
        else:
            print('this type of class service is not available for this train')
 



    elif t=='767' or t=='768' or t=='doloncapa' or t=='dlncp':
        if c in san_dinaj:
        
            if a in final_destination and b in final_destination:
                if a in doloncapa and b in doloncapa:
                    s=san_dinaj.index(c)
                    w=doloncapa_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in doloncapa and b in doloncapa:
                    start=doloncapa.index(a)
                    end=doloncapa.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in doloncapa_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')     
            
            
        else:
            print('this type of class service is not available for this train')
            
   
    
    elif t=='707' or t=='708' or t=='tista' or t=='tst':
        if c in dhk_dewan:
            if a in final_destination and b in final_destination:
                if a in tista and b in tista:
                    s=dhk_dewan.index(c)
                    w=tista_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in tista and b in tista:
                    start=tista.index(a)
                    end=tista.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in tista_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
    elif t=='743' or t=='744' or t=='brahmaputro' or t=='brmptr':
        if c in dhk_dewan:
            if a in final_destination and b in final_destination:
                if a in brahmaputro and b in brahmaputro:
                    s=dhk_dewan.index(c)
                    w=brahmaputro_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in brahmaputro and b in brahmaputro:
                    start=brahmaputro.index(a)
                    end=brahmaputro.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in brahmaputro_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
            
        else:
            print('this type of class service is not available for this train')
            
            
            
           
    elif t=='709' or t=='710' or t=='parabat' or t=='prbt':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in parabat and b in parabat:
                    s=dhk_syl.index(c)
                    w=parabat_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in parabat and b in parabat:
                    start=parabat.index(a)
                    end=parabat.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in parabat_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
          
            
            
    elif t=='717' or t=='718' or t=='joyenteeka' or t=='jyntk':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in joyenteeka and b in joyenteeka:
                    s=dhk_syl.index(c)
                    w=joyenteeka_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in joyenteeka and b in joyenteeka:
                    start=joyenteeka.index(a)
                    end=joyenteeka.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in joyenteeka_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='773' or t=='774' or t=='kalni' or t=='kln':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in kalni and b in kalni:
                    s=dhk_syl.index(c)
                    w=kalni_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in kalni and b in kalni:
                    start=kalni.index(a)
                    end=kalni.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in kalni_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                    
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='739' or t=='740' or t=='upaban' or t=='pbn':
        if c in dhk_syl:
            
            if a in final_destination and b in final_destination:
                if a in upaban and b in upaban:
                    s=dhk_syl.index(c)
                    w=upaban_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in upaban and b in upaban:
                    start=upaban.index(a)
                    end=upaban.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in upaban_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')



    
    elif t=='711' or t=='712' or t=='upakul' or t=='pkl':
        if c in dhk_noa:
            
            if a in final_destination and b in final_destination:
                if a in upakul and b in upakul:
                    s=dhk_noa.index(c)
                    w=upakul_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in upakul and b in upakul:
                    start=upakul.index(a)
                    end=upakul.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in upakul_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='713' or t=='714' or t=='korotaya' or t=='krty':
        if c in san_buri:
            
            if a in final_destination and b in final_destination:
                if a in upaban and b in upaban:
                    s=san_buri.index(c)
                    w=upaban_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                print('sorry no service recored')
                         
        else:
            print('this type of class service is not available for this train')
            
                      
            
    elif t=='719' or t=='720' or t=='paharika' or t=='prk':
        if c in ctg_syl:
            
            if a in final_destination and b in final_destination:
                if a in paharika and b in paharika:
                    s=ctg_syl.index(c)
                    w=paharika_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in paharika and b in paharika:
                    start=paharika.index(a)
                    end=paharika.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in paharika_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='723' or t=='724' or t=='udayan' or t=='dyn':
        if c in ctg_syl:
            
            if a in final_destination and b in final_destination:
                if a in udayan and b in udayan:
                    s=ctg_syl.index(c)
                    w=udayan_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in udayan and b in udayan:
                    start=udayan.index(a)
                    end=udayan.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in udayan_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')  
            
            
            
    elif t=='729' or t=='730' or t=='meghna' or t=='mgn':
        if c in ctg_chand:
            
            if a in final_destination and b in final_destination:
                if a in meghna and b in meghna:
                    s=ctg_chand.index(c)
                    w=meghna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in meghna and b in meghna:
                    start=meghna.index(a)
                    end=meghna.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in meghna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
                      
            
    elif t=='735' or t=='736' or t=='augnibina' or t=='agnbn':
        if c in dhk_tara:
            
            if a in final_destination and b in final_destination:
                if a in augnibina and b in augnibina:
                    s=dhk_tara.index(c)
                    w=augnibina_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in augnibina and b in augnibina:
                    start=augnibina.index(a)
                    end=augnibina.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in augnibina_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='745' or t=='746' or t=='jamuna' or t=='jmn':
        if c in dhk_tara:
            
            if a in final_destination and b in final_destination:
                if a in jamuna and b in jamuna:
                    s=dhk_tara.index(c)
                    w=jamuna_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in jamuna and b in jamuna:
                    start=jamuna.index(a)
                    end=jamuna.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in jamuna_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')   
            
            
          
            
    elif t=='749' or t=='750' or t=='egarosindur_godhuli' or t=='grsndr_gdl':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in egarosindur_godhuli and b in egarosindur_godhuli:
                    s=dhk_kisore.index(c)
                    w=egarosindur_godhuli_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in egarosindur_godhuli and b in egarosindur_godhuli:
                    start=egarosindur_godhuli.index(a)
                    end=egarosindur_godhuli.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in egarosindur_godhuli_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
           
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
             
            
            
    elif t=='737' or t=='738' or t=='egarosindur_provati' or t=='grsndr_prvt':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in egarosindur_provati and b in egarosindur_provati:
                    s=dhk_kisore.index(c)
                    w=egarosindur_provati_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in egarosindur_provati and b in egarosindur_provati:
                    start=egarosindur_provati.index(a)
                    end=egarosindur_provati.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in egarosindur_provati_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='781' or t=='782' or t=='kishoreganj' or t=='ksrgnj':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in kishoreganj and b in kishoreganj:
                    s=dhk_kisore.index(c)
                    w=kishoreganj_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in kishoreganj and b in kishoreganj:
                    start=kishoreganj.index(a)
                    end=kishoreganj.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in kishoreganj_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')   
                        
            

    elif t=='751' or t=='752' or t=='lalmoni' or t=='llmn':
        if c in dhk_lal:
            
            if a in final_destination and b in final_destination:
                if a in lalmoni and b in lalmoni:
                    s=dhk_lal.index(c)
                    w=lalmoni_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in lalmoni and b in lalmoni:
                    start=lalmoni.index(a)
                    end=lalmoni.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in lalmoni_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
           
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
             
            
            
    elif t=='771' or t=='772' or t=='rangpur' or t=='rngpr':
        if c in dhk_rang:
            
            if a in final_destination and b in final_destination:
                if a in rangpur and b in rangpur:
                    s=dhk_rang.index(c)
                    w=rangpur_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in rangpur and b in rangpur:
                    start=rangpur.index(a)
                    end=rangpur.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in rangpur_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='797' or t=='798' or t=='kurigram' or t=='krgrm':
        if c in dhk_kisore:
            
            if a in final_destination and b in final_destination:
                if a in kurigram and b in kurigram:
                    s=dhk_kisore.index(c)
                    w=kurigram_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in kurigram and b in kurigram:
                    start=kurigram.index(a)
                    end=kurigram.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in kurigram_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')             
            
          
            
            
    elif t=='797' or t=='799' and t=='mohonganj' or t=='mngnj':
        if c in dhk_mohon:
            
            if a in final_destination and b in final_destination:
                if a in mohonganj and b in mohonganj:
                    s=dhk_mohon.index(c)
                    w=mohonganj_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in mohonganj and b in mohonganj:
                    start=mohonganj.index(a)
                    end=mohonganj.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in mohonganj_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='777' or t=='778' or t=='haowr' or t=='wr':
        if c in dhk_mohon:
            
            if a in final_destination and b in final_destination:
                if a in haowr and b in haowr:
                    s=dhk_mohon.index(c)
                    w=haowr_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in haowr and b in haowr:
                    start=haowr.index(a)
                    end=haowr.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in haowr_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')  
            
           
            
            
    elif t=='785' or t=='786' or t=='bijoy' or t=='bjy':
        if c in ctg_my:
            
            if a in final_destination and b in final_destination:
                if a in bijoy and b in bijoy:
                    s=ctg_my.index(c)
                    w=bijoy_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in bijoy and b in bijoy:
                    start=bijoy.index(a)
                    end=bijoy.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in bijoy_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
           
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
                        
            
    elif t=='761' or t=='762' or t=='shagordari' or t=='sgrdr':
        if c in khul_raj:
            
            if a in final_destination and b in final_destination:
                if a in shagordari and b in shagordari:
                    s=khul_raj.index(c)
                    w=shagordari_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in shagordari and b in shagordari:
                    start=shagordari.index(a)
                    end=shagordari.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in shagordari_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
                   
           
            
    elif t=='715' or t=='716' or t=='kopotakha' or t=='kptk':
        if c in khul_raj:
            
            if a in final_destination and b in final_destination:
                if a in kopotakha and b in kopotakha:
                    s=khul_raj.index(c)
                    w=kopotakha_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in kopotakha and b in kopotakha:
                    start=kopotakha.index(a)
                    end=kopotakha.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in kopotakha_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')             
            
          
    
    elif t=='763' or t=='764' or t=='chitra' or t=='ctr':
        if c in khul_dhk:
            
            if a in final_destination and b in final_destination:
                if a in chitra and b in chitra:
                    s=khul_dhk.index(c)
                    w=chitra_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in chitra and b in chitra:
                    start=chitra.index(a)
                    end=chitra.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in chitra_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            
            
            
            
    elif t=='725' or t=='726' or t=='sundarban' or t=='sndrbn':            
        if c in khul_dhk:
            
            if a in final_destination and b in final_destination:
                if a in sundarban and b in sundarban:
                    s=khul_dhk.index(c)
                    w=sundarban_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in sundarban and b in sundarban:
                    start=sundarban.index(a)
                    end=sundarban.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in sundarban_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')           
            
                             
            
            
    elif t=='747' or t=='748' or t=='seemanta' or t=='smnt':            
        if c in khul_chila:
            
            if a in final_destination and b in final_destination:
                if a in seemanta and b in seemanta:
                    s=khul_chila.index(c)
                    w=seemanta_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in seemanta and b in seemanta:
                    start=seemanta.index(a)
                    end=seemanta.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in seemanta_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
           
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
                        
            
    elif t=='727' or t=='728' or t=='rupsa' or t=='rps':
        if c in khul_chila:
            
            if a in final_destination and b in final_destination:
                if a in rupsa and b in rupsa:
                    s=khul_chila.index(c)
                    w=rupsa_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in rupsa and b in rupsa:
                    start=rupsa.index(a)
                    end=rupsa.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in rupsa_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            


            
    elif t=='733' or t=='734' or t=='titumir' or t=='ttmr':
        if c in raj_chila:
            
            if a in final_destination and b in final_destination:
                if a in titumir and b in titumir:
                    s=raj_chila.index(c)
                    w=titumir_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in titumir and b in titumir:
                    start=titumir.index(a)
                    end=titumir.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in titumir_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')             
            
          
    
    elif t=='731' or t=='732' or t=='borendra' or t=='brndr':
        if c in raj_chila:
            
            if a in final_destination and b in final_destination:
                if a in borendra and b in borendra:
                    s=raj_chila.index(c)
                    w=borendra_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in borendra and b in borendra:
                    start=borendra.index(a)
                    end=borendra.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in borendra_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            



    elif t=='769' or t=='770' or t=='dhumkatu' or t=='dmkt':
        if c in raj_dhk:
            
            if a in final_destination and b in final_destination:
                if a in dhumkatu and b in dhumkatu:
                    s=raj_dhk.index(c)
                    w=dhumkatu_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in dhumkatu and b in dhumkatu:
                    start=dhumkatu.index(a)
                    end=dhumkatu.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in dhumkatu_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')           
            
                             
            
            
    elif t=='759' or t=='760' or t=='padma' or t=='pdm':
        if c in raj_dhk:
            
            if a in final_destination and b in final_destination:
                if a in padma and b in padma:
                    s=raj_dhk.index(c)
                    w=padma_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in padma and b in padma:
                    start=padma.index(a)
                    end=padma.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in padma_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
           
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
                         
        else:
            print('this type of class service is not available for this train')
            
                        
            
    elif t=='753' or t=='754' or t=='silk_city' or t=='slk_cty':
        if c in raj_dhk:
            
            if a in final_destination and b in final_destination:
                if a in silk_city and b in silk_city:
                    s=raj_dhk.index(c)
                    w=silk_city_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in silk_city and b in silk_city:
                    start=silk_city.index(a)
                    end=silk_city.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in silk_city_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')
            

           
    elif t=='791' or t=='792' or t=='banalata' or t=='bnlt':
        if c in raj_dhk:
            
            if a in final_destination and b in final_destination:
                if a in banalata and b in banalata:
                    s=raj_dhk.index(c)
                    w=banalata_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in banalata and b in banalata:
                    start=banalata.index(a)
                    end=banalata.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in banalata_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')             
            

 
    elif t=='775' or t=='776' or t=='sirajganj' or t=='srjgnj':
        if c in dhk_siraj:
            
            if a in final_destination and b in final_destination:
                if a in sirajganj and b in sirajganj:
                    s=dhk_siraj.index(c)
                    w=sirajganj_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in sirajganj and b in sirajganj:
                    start=sirajganj.index(a)
                    end=sirajganj.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in sirajganj_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')




            
            
    elif t=='765' or t=='766' or t=='nelsagore' or t=='nlsgr':
        if c in dhk_chila:
            
            if a in final_destination and b in final_destination:
                if a in nelsagore and b in nelsagore:
                    s=dhk_chila.index(c)
                    w=nelsagore_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                if a in nelsagore and b in nelsagore:
                    start=nelsagore.index(a)
                    end=nelsagore.index(b)
                    
                    if start>end:
                        ends=start
                        starts=end
                    else:
                        ends=end
                        starts=start
                        
                    for i in nelsagore_raw_cost:
                        count=count+1
                        if count==ends:
                            break
                        if count>=starts:
                            cost=cost+int(i)
                            
 
                   
                    if c=="s_chair":
                        print(cost)
                    else:
                        print('sorry no service recored')
                        
                else:
                    print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')                
         
           
              
            
    elif t=='755' or t=='756' or t=='modhumati' or t=='mdmt':
        if c in rajba_goa:
            
            if a in final_destination and b in final_destination:
                if a in modhumati and b in modhumati:
                    s=rajba_goa.index(c)
                    w=modhumati_cost[s]
                    if w=='0':
                        print('this class service is not available')
                    else:
                        print(w)
                else:
                    ('this train does not go there')
            else:
                print('this train does not go there')  
        else:
            print('this type of class service is not available for this train')                
         
                


    else:
        print('train name invalid')          
            
    