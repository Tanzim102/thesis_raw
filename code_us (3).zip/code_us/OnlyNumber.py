#OK

def giveAnsOfP3(n):

    if n=='subarna' or n=='sbrn':
        print('Train no: 701 and 702')
    elif n=='mahanagar_godhuli'  or n=='mngr_gdl':
        print('Train no: 703')
    elif n=='mahanagar_provati' or n=='mngr_prvt':
        print('Train no: 704')
    elif n=='ekota' or n=='kt':
        print('Train no: 705 and 706')
    elif n=='tista'  or n=='tst':
        print('Train no: 707 and 708')
    elif n=='parabat' or n=='prbt':
        print('Train no: 709 and 710')
    elif n=='upakul' or n=='pkl':
        print('Train no: 711 and 712')
    elif n=='korotaya' or n=='krty':
        print('Train no: 713 and 714')
    elif n=='joyenteeka' or n=='jyntk':
        print('Train no: 717 and 718')
    elif n=='paharika' or n=='prk':
        print('Train no: 719 and 720')
    elif n=='mahanagar' or n=='mngr':
        print('Train no: 721 and 722')
    elif n=='udayan' or n=='dyn':
        print('Train no: 723 and 724')
    elif n=='meghna' or n=='mgn':
        print('Train no: 729 and 730')
    elif n=='augnibina' or n=='agnbn':
        print('Train no: 735 and 736')
    elif n=='egarosindur_provati' or n=='grsndr_prvt':
        print('Train no: 737 and 738')
    elif n=='upaban' or n=='pbn':
        print('Train no: 739 and 740')               
    elif n=='turna' or n=='trn':
        print('Train no: 741 and 742')
    elif n=='brahmaputro' or n=='brmptr':
        print('Train no: 743 and 744')
    elif n=='jamuna' or n=='jmn':
        print('Train no: 745 and 746')
    elif n=='egarosindur_godhuli' or n=='grsndr_gdl':
        print('Train no: 749 and 750')
    elif n=='lalmoni' or n=='llmn':
        print('Train no: 751 and 752')
    elif n=='drutajan' or n=='drtjn':
        print('Train no: 757 and 758')
    elif n=='doloncapa' or n=='dlncp':
        print('Train no: 767 and 768')
    elif n=='rangpur' or n=='rngpr':
        print('Train no: 771 and 772')
    elif n=='kalni' or n=='kln':
        print('Train no: 773 and 774')
    elif n=='haowr' or n=='wr':
        print('Train no: 777 and 778')
    elif n=='kishoreganj' or n=='ksrgnj':
        print('Train no: 781 and 782')
    elif n=='bijoy' or n=='bjy':
        print('Train no: 785 and 786')
    elif n=='sonar_bangla' or n=='snr_bngl':
        print('Train no: 787 and 788')         
    elif n=='mohonganj' or n=='mngnj':
        print('Train no: 789 and 790')
    elif n=='kopotakha'  or n=='kptk':
        print('Train no: 715 and 716')
    elif n=='sundarban' or n=='sndrbn':
        print('Train no: 725 and 726')
    elif n=='rupsa' or n=='rps':
        print('Train no: 727 and 728')
    elif n=='borendra' or n=='brndr':
        print('Train no: 731 and 732')
    elif n=='titumir' or n=='ttmr':
        print('Train no: 733 and 734')
    elif n=='seemanta' or n=='smnt':
        print('Train no: 747 and 748')
    elif n=='silk_city' or n=='slk_cty':
        print('Train no: 753 and 754')
    elif n=='modhumati' or n=='mdmt':
        print('Train no: 755 and 756')
    elif n=='padma' or n=='pdm':
        print('Train no: 759 and 760')
    elif n=='shagordari' or n=='sgrdr':
        print('Train no: 761 and 762')
    elif n=='chitra' or n=='ctr':
        print('Train no: 763 and 764')
    elif n=='nelsagore' or n=='nlsgr':
        print('Train no: 765 and 766')
    elif n=='dhumkatu' or n=='dmkt':
        print('Train no: 769 and 770')              
    elif n=='sirajganj' or n=='srjgnj':
        print('Train no: 775 and 776')
    elif n=='kalukhali_vatiap' or n=='klkl_vtp':
        print('Train no: 779 and 780')
    elif n=='faridpur' or n=='frdpr':
        print('Train no: 783 and 784')
    elif n=='banalata' or n=='bnlt':
        print('Train no: 791 and 792')
    elif n=='panchagarh' or n=='pncgr':
        print('Train no: 793 and 794')
    elif n=='kurigram' or n=='krgrm':
        print('Train no: 797 and 798')
    elif n=='moitree' or n=='mtr':
        print('Train no: 3107/3110 and 3108/3109')
    elif n=='bandhan' or n=='bndn':
        print('Train no: 3129 and 3130') 
        
    else:
        print('Invalid Train name')